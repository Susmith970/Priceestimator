import { pgTable, text, serial, integer, boolean, numeric, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User schema (original from template)
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

// Properties schema for real estate listings
export const properties = pgTable("properties", {
  id: serial("id").primaryKey(),
  address: text("address").notNull(),
  city: text("city").notNull(),
  state: text("state").notNull(),
  zipCode: text("zip_code").notNull(),
  price: numeric("price").notNull(),
  bedrooms: integer("bedrooms").notNull(),
  bathrooms: numeric("bathrooms").notNull(),
  squareFeet: integer("square_feet").notNull(),
  lotSize: numeric("lot_size"),
  yearBuilt: integer("year_built"),
  propertyType: text("property_type").notNull(),
  description: text("description"),
  hasGarage: boolean("has_garage").default(false),
  hasPool: boolean("has_pool").default(false),
  hasFireplace: boolean("has_fireplace").default(false),
  hasRenovatedKitchen: boolean("has_renovated_kitchen").default(false),
  hasBasement: boolean("has_basement").default(false),
  hasSolarPanels: boolean("has_solar_panels").default(false),
  listingDate: timestamp("listing_date").notNull(),
  imageUrl: text("image_url"),
  priceChange: numeric("price_change"),
  schoolRating: integer("school_rating"),
  walkScore: integer("walk_score"),
});

export const insertPropertySchema = createInsertSchema(properties).omit({
  id: true,
});

// Neighborhoods schema for analytics
export const neighborhoods = pgTable("neighborhoods", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  city: text("city").notNull(),
  state: text("state").notNull(),
  zipCode: text("zip_code").notNull(),
  averagePrice: numeric("average_price").notNull(),
  pricePerSqFt: numeric("price_per_sqft").notNull(),
  annualAppreciation: numeric("annual_appreciation"),
  marketHeat: text("market_heat").notNull(),
});

export const insertNeighborhoodSchema = createInsertSchema(neighborhoods).omit({
  id: true,
});

// Price estimation schema
export const priceEstimates = pgTable("price_estimates", {
  id: serial("id").primaryKey(),
  address: text("address").notNull(),
  estimatedPrice: numeric("estimated_price").notNull(),
  minRange: numeric("min_range").notNull(),
  maxRange: numeric("max_range").notNull(),
  confidenceScore: integer("confidence_score").notNull(),
  createdAt: timestamp("created_at").notNull(),
  bedrooms: integer("bedrooms").notNull(),
  bathrooms: numeric("bathrooms").notNull(),
  squareFeet: integer("square_feet").notNull(),
  propertyType: text("property_type").notNull(),
  yearBuilt: integer("year_built"),
});

export const insertPriceEstimateSchema = createInsertSchema(priceEstimates).omit({
  id: true,
});

// Export types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertProperty = z.infer<typeof insertPropertySchema>;
export type Property = typeof properties.$inferSelect;

export type InsertNeighborhood = z.infer<typeof insertNeighborhoodSchema>;
export type Neighborhood = typeof neighborhoods.$inferSelect;

export type InsertPriceEstimate = z.infer<typeof insertPriceEstimateSchema>;
export type PriceEstimate = typeof priceEstimates.$inferSelect;
