import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertPropertySchema, insertPriceEstimateSchema } from "@shared/schema";
import { ZodError } from "zod";
import { fromZodError } from "zod-validation-error";

function handleZodError(err: ZodError, res: Response) {
  const validationError = fromZodError(err);
  return res.status(400).json({ message: validationError.message });
}

export async function registerRoutes(app: Express): Promise<Server> {
  // API routes prefix
  const apiPrefix = "/api";
  
  // Get all properties with optional filters
  app.get(`${apiPrefix}/properties`, async (req: Request, res: Response) => {
    try {
      const filters = req.query;
      
      // Convert query parameters to proper types
      const propertyFilters = {
        minPrice: filters.minPrice ? Number(filters.minPrice) : undefined,
        maxPrice: filters.maxPrice ? Number(filters.maxPrice) : undefined,
        minBedrooms: filters.minBedrooms ? Number(filters.minBedrooms) : undefined,
        minBathrooms: filters.minBathrooms ? Number(filters.minBathrooms) : undefined,
        minSquareFeet: filters.minSquareFeet ? Number(filters.minSquareFeet) : undefined,
        maxSquareFeet: filters.maxSquareFeet ? Number(filters.maxSquareFeet) : undefined,
        propertyTypes: filters.propertyTypes ? String(filters.propertyTypes).split(',') : undefined,
        hasGarage: filters.hasGarage === 'true' ? true : filters.hasGarage === 'false' ? false : undefined,
        hasPool: filters.hasPool === 'true' ? true : filters.hasPool === 'false' ? false : undefined,
        hasFireplace: filters.hasFireplace === 'true' ? true : filters.hasFireplace === 'false' ? false : undefined,
        hasRenovatedKitchen: filters.hasRenovatedKitchen === 'true' ? true : filters.hasRenovatedKitchen === 'false' ? false : undefined,
        hasBasement: filters.hasBasement === 'true' ? true : filters.hasBasement === 'false' ? false : undefined,
        hasSolarPanels: filters.hasSolarPanels === 'true' ? true : filters.hasSolarPanels === 'false' ? false : undefined,
        city: filters.city ? String(filters.city) : undefined,
        state: filters.state ? String(filters.state) : undefined,
        zipCode: filters.zipCode ? String(filters.zipCode) : undefined,
      };
      
      const properties = await storage.getProperties(propertyFilters);
      res.json(properties);
    } catch (err) {
      res.status(500).json({ message: "Error fetching properties" });
    }
  });
  
  // Get a single property by ID
  app.get(`${apiPrefix}/properties/:id`, async (req: Request, res: Response) => {
    try {
      const id = Number(req.params.id);
      const property = await storage.getPropertyById(id);
      
      if (!property) {
        return res.status(404).json({ message: "Property not found" });
      }
      
      res.json(property);
    } catch (err) {
      res.status(500).json({ message: "Error fetching property" });
    }
  });
  
  // Create a new property
  app.post(`${apiPrefix}/properties`, async (req: Request, res: Response) => {
    try {
      const propertyData = insertPropertySchema.parse(req.body);
      const property = await storage.createProperty(propertyData);
      res.status(201).json(property);
    } catch (err) {
      if (err instanceof ZodError) {
        return handleZodError(err, res);
      }
      res.status(500).json({ message: "Error creating property" });
    }
  });
  
  // Update a property
  app.patch(`${apiPrefix}/properties/:id`, async (req: Request, res: Response) => {
    try {
      const id = Number(req.params.id);
      const propertyData = req.body;
      
      const updatedProperty = await storage.updateProperty(id, propertyData);
      
      if (!updatedProperty) {
        return res.status(404).json({ message: "Property not found" });
      }
      
      res.json(updatedProperty);
    } catch (err) {
      res.status(500).json({ message: "Error updating property" });
    }
  });
  
  // Delete a property
  app.delete(`${apiPrefix}/properties/:id`, async (req: Request, res: Response) => {
    try {
      const id = Number(req.params.id);
      const success = await storage.deleteProperty(id);
      
      if (!success) {
        return res.status(404).json({ message: "Property not found" });
      }
      
      res.status(204).send();
    } catch (err) {
      res.status(500).json({ message: "Error deleting property" });
    }
  });
  
  // Get all neighborhoods
  app.get(`${apiPrefix}/neighborhoods`, async (_req: Request, res: Response) => {
    try {
      const neighborhoods = await storage.getNeighborhoods();
      res.json(neighborhoods);
    } catch (err) {
      res.status(500).json({ message: "Error fetching neighborhoods" });
    }
  });
  
  // Get neighborhood by ZIP code
  app.get(`${apiPrefix}/neighborhoods/:zipCode`, async (req: Request, res: Response) => {
    try {
      const zipCode = req.params.zipCode;
      const neighborhood = await storage.getNeighborhoodByZipCode(zipCode);
      
      if (!neighborhood) {
        return res.status(404).json({ message: "Neighborhood not found" });
      }
      
      res.json(neighborhood);
    } catch (err) {
      res.status(500).json({ message: "Error fetching neighborhood" });
    }
  });
  
  // Create a price estimate
  app.post(`${apiPrefix}/estimate`, async (req: Request, res: Response) => {
    try {
      const estimateData = insertPriceEstimateSchema.parse(req.body);
      
      // Simple price estimation logic
      const basePrice = 500 * estimateData.squareFeet;
      const bedroomFactor = estimateData.bedrooms * 10000;
      const bathroomFactor = Number(estimateData.bathrooms) * 15000;
      const ageFactor = estimateData.yearBuilt ? Math.max(0, (new Date().getFullYear() - estimateData.yearBuilt)) * 1000 : 0;
      
      const estimatedPrice = basePrice + bedroomFactor + bathroomFactor - ageFactor;
      const variance = estimatedPrice * 0.05; // 5% variance
      
      const estimate = {
        ...estimateData,
        estimatedPrice,
        minRange: estimatedPrice - variance,
        maxRange: estimatedPrice + variance,
        confidenceScore: 80, // Default confidence score
        createdAt: new Date()
      };
      
      const savedEstimate = await storage.createPriceEstimate(estimate);
      res.status(201).json(savedEstimate);
    } catch (err) {
      if (err instanceof ZodError) {
        return handleZodError(err, res);
      }
      res.status(500).json({ message: "Error creating price estimate" });
    }
  });
  
  // Get price estimates by address
  app.get(`${apiPrefix}/estimates`, async (req: Request, res: Response) => {
    try {
      const address = req.query.address as string;
      
      if (!address) {
        return res.status(400).json({ message: "Address is required" });
      }
      
      const estimates = await storage.getPriceEstimatesByAddress(address);
      res.json(estimates);
    } catch (err) {
      res.status(500).json({ message: "Error fetching price estimates" });
    }
  });
  
  const httpServer = createServer(app);
  return httpServer;
}
