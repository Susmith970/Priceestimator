import { 
  User, InsertUser, users, 
  Property, InsertProperty, properties,
  Neighborhood, InsertNeighborhood, neighborhoods,
  PriceEstimate, InsertPriceEstimate, priceEstimates
} from "@shared/schema";

// Storage interface with CRUD methods
export interface IStorage {
  // User methods (from original template)
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Property methods
  getProperties(filters?: PropertyFilters): Promise<Property[]>;
  getPropertyById(id: number): Promise<Property | undefined>;
  createProperty(property: InsertProperty): Promise<Property>;
  updateProperty(id: number, property: Partial<InsertProperty>): Promise<Property | undefined>;
  deleteProperty(id: number): Promise<boolean>;
  
  // Neighborhood methods
  getNeighborhoods(): Promise<Neighborhood[]>;
  getNeighborhoodByZipCode(zipCode: string): Promise<Neighborhood | undefined>;
  createNeighborhood(neighborhood: InsertNeighborhood): Promise<Neighborhood>;
  
  // Price estimate methods
  createPriceEstimate(estimate: InsertPriceEstimate): Promise<PriceEstimate>;
  getPriceEstimatesByAddress(address: string): Promise<PriceEstimate[]>;
}

// Property filters for search
export interface PropertyFilters {
  minPrice?: number;
  maxPrice?: number;
  minBedrooms?: number;
  minBathrooms?: number;
  minSquareFeet?: number;
  maxSquareFeet?: number;
  propertyTypes?: string[];
  hasGarage?: boolean;
  hasPool?: boolean;
  hasFireplace?: boolean;
  hasRenovatedKitchen?: boolean;
  hasBasement?: boolean;
  hasSolarPanels?: boolean;
  city?: string;
  state?: string;
  zipCode?: string;
}

// Memory storage implementation
export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private properties: Map<number, Property>;
  private neighborhoods: Map<number, Neighborhood>;
  private priceEstimates: Map<number, PriceEstimate>;
  
  private userCurrentId: number;
  private propertyCurrentId: number;
  private neighborhoodCurrentId: number;
  private estimateCurrentId: number;

  constructor() {
    this.users = new Map();
    this.properties = new Map();
    this.neighborhoods = new Map();
    this.priceEstimates = new Map();
    
    this.userCurrentId = 1;
    this.propertyCurrentId = 1;
    this.neighborhoodCurrentId = 1;
    this.estimateCurrentId = 1;
    
    // Initialize with sample data
    this.initializeSampleData();
  }

  // User methods (from original template)
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userCurrentId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }
  
  // Property methods
  async getProperties(filters?: PropertyFilters): Promise<Property[]> {
    let properties = Array.from(this.properties.values());
    
    if (filters) {
      if (filters.minPrice !== undefined) {
        properties = properties.filter(p => Number(p.price) >= filters.minPrice!);
      }
      
      if (filters.maxPrice !== undefined) {
        properties = properties.filter(p => Number(p.price) <= filters.maxPrice!);
      }
      
      if (filters.minBedrooms !== undefined) {
        properties = properties.filter(p => p.bedrooms >= filters.minBedrooms!);
      }
      
      if (filters.minBathrooms !== undefined) {
        properties = properties.filter(p => Number(p.bathrooms) >= filters.minBathrooms!);
      }
      
      if (filters.minSquareFeet !== undefined) {
        properties = properties.filter(p => p.squareFeet >= filters.minSquareFeet!);
      }
      
      if (filters.maxSquareFeet !== undefined) {
        properties = properties.filter(p => p.squareFeet <= filters.maxSquareFeet!);
      }
      
      if (filters.propertyTypes && filters.propertyTypes.length > 0) {
        properties = properties.filter(p => filters.propertyTypes!.includes(p.propertyType));
      }
      
      if (filters.hasGarage !== undefined) {
        properties = properties.filter(p => p.hasGarage === filters.hasGarage);
      }
      
      if (filters.hasPool !== undefined) {
        properties = properties.filter(p => p.hasPool === filters.hasPool);
      }
      
      if (filters.hasFireplace !== undefined) {
        properties = properties.filter(p => p.hasFireplace === filters.hasFireplace);
      }
      
      if (filters.hasRenovatedKitchen !== undefined) {
        properties = properties.filter(p => p.hasRenovatedKitchen === filters.hasRenovatedKitchen);
      }
      
      if (filters.hasBasement !== undefined) {
        properties = properties.filter(p => p.hasBasement === filters.hasBasement);
      }
      
      if (filters.hasSolarPanels !== undefined) {
        properties = properties.filter(p => p.hasSolarPanels === filters.hasSolarPanels);
      }
      
      if (filters.city !== undefined) {
        properties = properties.filter(p => p.city.toLowerCase().includes(filters.city!.toLowerCase()));
      }
      
      if (filters.state !== undefined) {
        properties = properties.filter(p => p.state.toLowerCase() === filters.state!.toLowerCase());
      }
      
      if (filters.zipCode !== undefined) {
        properties = properties.filter(p => p.zipCode === filters.zipCode);
      }
    }
    
    return properties;
  }
  
  async getPropertyById(id: number): Promise<Property | undefined> {
    return this.properties.get(id);
  }
  
  async createProperty(property: InsertProperty): Promise<Property> {
    const id = this.propertyCurrentId++;
    const newProperty: Property = { ...property, id };
    this.properties.set(id, newProperty);
    return newProperty;
  }
  
  async updateProperty(id: number, property: Partial<InsertProperty>): Promise<Property | undefined> {
    const existingProperty = this.properties.get(id);
    
    if (!existingProperty) {
      return undefined;
    }
    
    const updatedProperty: Property = { ...existingProperty, ...property };
    this.properties.set(id, updatedProperty);
    return updatedProperty;
  }
  
  async deleteProperty(id: number): Promise<boolean> {
    return this.properties.delete(id);
  }
  
  // Neighborhood methods
  async getNeighborhoods(): Promise<Neighborhood[]> {
    return Array.from(this.neighborhoods.values());
  }
  
  async getNeighborhoodByZipCode(zipCode: string): Promise<Neighborhood | undefined> {
    return Array.from(this.neighborhoods.values()).find(
      (neighborhood) => neighborhood.zipCode === zipCode,
    );
  }
  
  async createNeighborhood(neighborhood: InsertNeighborhood): Promise<Neighborhood> {
    const id = this.neighborhoodCurrentId++;
    const newNeighborhood: Neighborhood = { ...neighborhood, id };
    this.neighborhoods.set(id, newNeighborhood);
    return newNeighborhood;
  }
  
  // Price estimate methods
  async createPriceEstimate(estimate: InsertPriceEstimate): Promise<PriceEstimate> {
    const id = this.estimateCurrentId++;
    const newEstimate: PriceEstimate = { ...estimate, id };
    this.priceEstimates.set(id, newEstimate);
    return newEstimate;
  }
  
  async getPriceEstimatesByAddress(address: string): Promise<PriceEstimate[]> {
    return Array.from(this.priceEstimates.values()).filter(
      (estimate) => estimate.address.toLowerCase().includes(address.toLowerCase()),
    );
  }
  
  // Initialize sample data
  private initializeSampleData() {
    // Sample properties
    const sampleProperties: InsertProperty[] = [
      {
        address: "123 Main Street",
        city: "Pleasantville",
        state: "CA",
        zipCode: "91234",
        price: 749000,
        bedrooms: 4,
        bathrooms: 2.5,
        squareFeet: 2456,
        lotSize: 0.25,
        yearBuilt: 2015,
        propertyType: "Single Family Home",
        description: "Beautiful modern home with pool and updated features.",
        hasGarage: true,
        hasPool: true,
        hasFireplace: false,
        hasRenovatedKitchen: true,
        hasBasement: false,
        hasSolarPanels: false,
        listingDate: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000), // 3 days ago
        imageUrl: "https://images.unsplash.com/photo-1592595896616-c37162298647?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&h=300&q=80",
        priceChange: 3.2,
        schoolRating: 8,
        walkScore: 65
      },
      {
        address: "456 Oak Drive",
        city: "Pleasantville",
        state: "CA",
        zipCode: "91234",
        price: 925000,
        bedrooms: 5,
        bathrooms: 3,
        squareFeet: 3120,
        lotSize: 0.38,
        yearBuilt: 2010,
        propertyType: "Single Family Home",
        description: "Luxury suburban home with spacious rooms and modern amenities.",
        hasGarage: true,
        hasPool: false,
        hasFireplace: true,
        hasRenovatedKitchen: true,
        hasBasement: false,
        hasSolarPanels: false,
        listingDate: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000), // 1 week ago
        imageUrl: "https://images.unsplash.com/photo-1564013799919-ab600027ffc6?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&h=300&q=80",
        priceChange: 5.8,
        schoolRating: 9,
        walkScore: 78
      },
      {
        address: "789 Pine Court",
        city: "Pleasantville",
        state: "CA",
        zipCode: "91234",
        price: 599000,
        bedrooms: 3,
        bathrooms: 2,
        squareFeet: 1890,
        lotSize: 0.2,
        yearBuilt: 2008,
        propertyType: "Single Family Home",
        description: "Mediterranean style home with beautiful landscaping.",
        hasGarage: true,
        hasPool: false,
        hasFireplace: true,
        hasRenovatedKitchen: false,
        hasBasement: false,
        hasSolarPanels: false,
        listingDate: new Date(Date.now() - 14 * 24 * 60 * 60 * 1000), // 2 weeks ago
        imageUrl: "https://images.unsplash.com/photo-1512917774080-9991f1c4c750?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&h=300&q=80",
        priceChange: -2.4,
        schoolRating: 7,
        walkScore: 60
      },
      {
        address: "321 Maple Avenue",
        city: "Pleasantville",
        state: "CA",
        zipCode: "91234",
        price: 510000,
        bedrooms: 2,
        bathrooms: 2.5,
        squareFeet: 1650,
        lotSize: 0.15,
        yearBuilt: 2018,
        propertyType: "Townhouse",
        description: "Modern townhouse in a great location.",
        hasGarage: true,
        hasPool: false,
        hasFireplace: false,
        hasRenovatedKitchen: true,
        hasBasement: false,
        hasSolarPanels: false,
        listingDate: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000), // 5 days ago
        imageUrl: "https://images.unsplash.com/photo-1523217582562-09d0def993a6?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&h=300&q=80",
        priceChange: 1.5,
        schoolRating: 8,
        walkScore: 70
      },
      {
        address: "654 Cedar Lane",
        city: "Pleasantville",
        state: "CA",
        zipCode: "91234",
        price: 879000,
        bedrooms: 4,
        bathrooms: 3,
        squareFeet: 2875,
        lotSize: 0.3,
        yearBuilt: 2012,
        propertyType: "Single Family Home",
        description: "Spacious family home with open floor plan.",
        hasGarage: true,
        hasPool: true,
        hasFireplace: true,
        hasRenovatedKitchen: true,
        hasBasement: true,
        hasSolarPanels: false,
        listingDate: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000), // 1 day ago
        imageUrl: "https://images.unsplash.com/photo-1570129477492-45c003edd2be?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&h=300&q=80",
        priceChange: 4.1,
        schoolRating: 9,
        walkScore: 75
      },
      {
        address: "987 Birch Street",
        city: "Pleasantville",
        state: "CA",
        zipCode: "91234",
        price: 685000,
        bedrooms: 3,
        bathrooms: 2,
        squareFeet: 2150,
        lotSize: 0.22,
        yearBuilt: 2005,
        propertyType: "Single Family Home",
        description: "Classic suburban home with modern updates.",
        hasGarage: true,
        hasPool: false,
        hasFireplace: true,
        hasRenovatedKitchen: false,
        hasBasement: false,
        hasSolarPanels: false,
        listingDate: new Date(Date.now() - 4 * 24 * 60 * 60 * 1000), // 4 days ago
        imageUrl: "https://images.unsplash.com/photo-1605276374104-dee2a0ed3cd6?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&h=300&q=80",
        priceChange: 2.7,
        schoolRating: 8,
        walkScore: 68
      }
    ];
    
    // Add sample properties
    sampleProperties.forEach(property => {
      this.createProperty(property);
    });
    
    // Sample neighborhood
    const pleasantville: InsertNeighborhood = {
      name: "Downtown Pleasantville",
      city: "Pleasantville",
      state: "CA",
      zipCode: "91234",
      averagePrice: 720500,
      pricePerSqFt: 386,
      annualAppreciation: 4.2,
      marketHeat: "Warm"
    };
    
    this.createNeighborhood(pleasantville);
  }
}

export const storage = new MemStorage();
