import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import { ChevronDown, ChevronUp } from 'lucide-react';

export interface FilterValues {
  priceMin?: string;
  priceMax?: string;
  propertyTypes: string[];
  bedrooms: string;
  bathrooms: string;
  sizeMin?: string;
  sizeMax?: string;
  hasGarage?: boolean;
  hasPool?: boolean;
  hasFireplace?: boolean;
  hasRenovatedKitchen?: boolean;
  hasBasement?: boolean;
  hasSolarPanels?: boolean;
}

interface FilterSidebarProps {
  filters: FilterValues;
  onChange: (filters: FilterValues) => void;
  onApply: () => void;
}

const FilterSidebar = ({ filters, onChange, onApply }: FilterSidebarProps) => {
  const [moreFiltersOpen, setMoreFiltersOpen] = useState(false);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    onChange({ ...filters, [name]: value });
  };

  const handlePropertyTypeChange = (type: string) => {
    const newTypes = filters.propertyTypes.includes(type)
      ? filters.propertyTypes.filter(t => t !== type)
      : [...filters.propertyTypes, type];
    
    onChange({ ...filters, propertyTypes: newTypes });
  };

  const handleBedroomsChange = (value: string) => {
    onChange({ ...filters, bedrooms: value });
  };

  const handleBathroomsChange = (value: string) => {
    onChange({ ...filters, bathrooms: value });
  };

  const handleCheckboxChange = (name: string, checked: boolean) => {
    onChange({ ...filters, [name]: checked });
  };

  return (
    <div className="bg-white p-4 rounded-lg shadow-sm border border-neutral-200">
      <h2 className="font-semibold text-lg mb-4">Filters</h2>
      
      {/* Price Range Filter */}
      <div className="mb-4">
        <h3 className="font-medium text-sm text-neutral-600 mb-2">Price Range</h3>
        <div className="flex items-center gap-2">
          <Input 
            type="text" 
            placeholder="Min" 
            name="priceMin"
            value={filters.priceMin}
            onChange={handleInputChange}
            className="w-1/2 p-2 border border-neutral-200 rounded"
          />
          <span className="text-neutral-600">to</span>
          <Input 
            type="text" 
            placeholder="Max" 
            name="priceMax"
            value={filters.priceMax}
            onChange={handleInputChange}
            className="w-1/2 p-2 border border-neutral-200 rounded"
          />
        </div>
      </div>
      
      {/* Property Type */}
      <div className="mb-4">
        <h3 className="font-medium text-sm text-neutral-600 mb-2">Property Type</h3>
        <div className="space-y-2">
          <div className="flex items-center">
            <Checkbox 
              id="houses" 
              checked={filters.propertyTypes.includes('Single Family Home')}
              onCheckedChange={(checked) => handlePropertyTypeChange('Single Family Home')}
              className="mr-2 text-primary"
            />
            <Label htmlFor="houses">Houses</Label>
          </div>
          <div className="flex items-center">
            <Checkbox 
              id="condos" 
              checked={filters.propertyTypes.includes('Condo/Townhouse')}
              onCheckedChange={(checked) => handlePropertyTypeChange('Condo/Townhouse')}
              className="mr-2 text-primary"
            />
            <Label htmlFor="condos">Condos/Co-ops</Label>
          </div>
          <div className="flex items-center">
            <Checkbox 
              id="townhomes" 
              checked={filters.propertyTypes.includes('Townhouse')}
              onCheckedChange={(checked) => handlePropertyTypeChange('Townhouse')}
              className="mr-2 text-primary"
            />
            <Label htmlFor="townhomes">Townhomes</Label>
          </div>
          <div className="flex items-center">
            <Checkbox 
              id="multifamily" 
              checked={filters.propertyTypes.includes('Multi-Family')}
              onCheckedChange={(checked) => handlePropertyTypeChange('Multi-Family')}
              className="mr-2 text-primary"
            />
            <Label htmlFor="multifamily">Multi-family</Label>
          </div>
        </div>
      </div>

      {/* Beds & Baths */}
      <div className="mb-4">
        <h3 className="font-medium text-sm text-neutral-600 mb-2">Beds & Baths</h3>
        <div className="mb-3">
          <p className="text-xs text-neutral-600 mb-1">Bedrooms</p>
          <div className="flex gap-2">
            <Button 
              type="button"
              onClick={() => handleBedroomsChange('any')}
              variant={filters.bedrooms === 'any' ? 'default' : 'outline'}
              size="sm"
              className="h-auto py-1"
            >
              Any
            </Button>
            <Button 
              type="button"
              onClick={() => handleBedroomsChange('1+')}
              variant={filters.bedrooms === '1+' ? 'default' : 'outline'}
              size="sm"
              className="h-auto py-1"
            >
              1+
            </Button>
            <Button 
              type="button"
              onClick={() => handleBedroomsChange('2+')}
              variant={filters.bedrooms === '2+' ? 'default' : 'outline'}
              size="sm"
              className="h-auto py-1"
            >
              2+
            </Button>
            <Button 
              type="button"
              onClick={() => handleBedroomsChange('3+')}
              variant={filters.bedrooms === '3+' ? 'default' : 'outline'}
              size="sm"
              className="h-auto py-1"
            >
              3+
            </Button>
            <Button 
              type="button"
              onClick={() => handleBedroomsChange('4+')}
              variant={filters.bedrooms === '4+' ? 'default' : 'outline'}
              size="sm"
              className="h-auto py-1"
            >
              4+
            </Button>
          </div>
        </div>
        <div>
          <p className="text-xs text-neutral-600 mb-1">Bathrooms</p>
          <div className="flex gap-2">
            <Button 
              type="button"
              onClick={() => handleBathroomsChange('any')}
              variant={filters.bathrooms === 'any' ? 'default' : 'outline'}
              size="sm"
              className="h-auto py-1"
            >
              Any
            </Button>
            <Button 
              type="button"
              onClick={() => handleBathroomsChange('1+')}
              variant={filters.bathrooms === '1+' ? 'default' : 'outline'}
              size="sm"
              className="h-auto py-1"
            >
              1+
            </Button>
            <Button 
              type="button"
              onClick={() => handleBathroomsChange('2+')}
              variant={filters.bathrooms === '2+' ? 'default' : 'outline'}
              size="sm"
              className="h-auto py-1"
            >
              2+
            </Button>
            <Button 
              type="button"
              onClick={() => handleBathroomsChange('3+')}
              variant={filters.bathrooms === '3+' ? 'default' : 'outline'}
              size="sm"
              className="h-auto py-1"
            >
              3+
            </Button>
            <Button 
              type="button"
              onClick={() => handleBathroomsChange('4+')}
              variant={filters.bathrooms === '4+' ? 'default' : 'outline'}
              size="sm"
              className="h-auto py-1"
            >
              4+
            </Button>
          </div>
        </div>
      </div>
      
      {/* Home Size */}
      <div className="mb-4">
        <h3 className="font-medium text-sm text-neutral-600 mb-2">Home Size</h3>
        <div className="flex items-center gap-2">
          <Input 
            type="text" 
            placeholder="Min sq ft" 
            name="sizeMin"
            value={filters.sizeMin}
            onChange={handleInputChange}
            className="w-1/2 p-2 border border-neutral-200 rounded"
          />
          <span className="text-neutral-600">to</span>
          <Input 
            type="text" 
            placeholder="Max sq ft" 
            name="sizeMax"
            value={filters.sizeMax}
            onChange={handleInputChange}
            className="w-1/2 p-2 border border-neutral-200 rounded"
          />
        </div>
      </div>
      
      {/* More Filters Toggle */}
      <div>
        <Button 
          type="button"
          variant="ghost"
          onClick={() => setMoreFiltersOpen(!moreFiltersOpen)}
          className="w-full flex justify-between items-center py-2 text-primary font-medium"
        >
          <span>More Filters</span>
          {moreFiltersOpen ? <ChevronUp size={16} /> : <ChevronDown size={16} />}
        </Button>
      </div>
      
      {/* Additional Features (Initially Hidden) */}
      {moreFiltersOpen && (
        <div className="mt-4 space-y-2">
          <h3 className="font-medium text-sm text-neutral-600 mb-2">Additional Features</h3>
          <div className="grid grid-cols-2 gap-2">
            <div className="flex items-center">
              <Checkbox 
                id="garage" 
                checked={filters.hasGarage}
                onCheckedChange={(checked) => handleCheckboxChange('hasGarage', Boolean(checked))}
                className="mr-2 text-primary"
              />
              <Label htmlFor="garage">Garage</Label>
            </div>
            <div className="flex items-center">
              <Checkbox 
                id="pool" 
                checked={filters.hasPool}
                onCheckedChange={(checked) => handleCheckboxChange('hasPool', Boolean(checked))}
                className="mr-2 text-primary"
              />
              <Label htmlFor="pool">Pool</Label>
            </div>
            <div className="flex items-center">
              <Checkbox 
                id="fireplace" 
                checked={filters.hasFireplace}
                onCheckedChange={(checked) => handleCheckboxChange('hasFireplace', Boolean(checked))}
                className="mr-2 text-primary"
              />
              <Label htmlFor="fireplace">Fireplace</Label>
            </div>
            <div className="flex items-center">
              <Checkbox 
                id="renovatedKitchen" 
                checked={filters.hasRenovatedKitchen}
                onCheckedChange={(checked) => handleCheckboxChange('hasRenovatedKitchen', Boolean(checked))}
                className="mr-2 text-primary"
              />
              <Label htmlFor="renovatedKitchen">Renovated Kitchen</Label>
            </div>
            <div className="flex items-center">
              <Checkbox 
                id="basement" 
                checked={filters.hasBasement}
                onCheckedChange={(checked) => handleCheckboxChange('hasBasement', Boolean(checked))}
                className="mr-2 text-primary"
              />
              <Label htmlFor="basement">Basement</Label>
            </div>
            <div className="flex items-center">
              <Checkbox 
                id="solarPanels" 
                checked={filters.hasSolarPanels}
                onCheckedChange={(checked) => handleCheckboxChange('hasSolarPanels', Boolean(checked))}
                className="mr-2 text-primary"
              />
              <Label htmlFor="solarPanels">Solar Panels</Label>
            </div>
          </div>
        </div>
      )}
      
      <div className="mt-4">
        <Button 
          type="button"
          variant="default"
          onClick={onApply}
          className="w-full"
        >
          Apply Filters
        </Button>
      </div>
    </div>
  );
};

export default FilterSidebar;
