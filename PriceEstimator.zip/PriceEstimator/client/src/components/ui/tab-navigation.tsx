import { Link } from 'wouter';

interface TabNavItem {
  label: string;
  href: string;
  isActive: boolean;
}

interface TabNavigationProps {
  tabs: TabNavItem[];
}

const TabNavigation = ({ tabs }: TabNavigationProps) => {
  return (
    <div className="border-b border-neutral-200 mb-6">
      <nav className="flex space-x-8 overflow-x-auto scrollbar-hide">
        {tabs.map((tab, index) => (
          <Link
            key={index}
            href={tab.href}
            className={`py-4 px-1 border-b-2 whitespace-nowrap ${
              tab.isActive 
                ? 'border-primary text-primary font-medium' 
                : 'border-transparent text-neutral-600 hover:text-primary font-medium'
            }`}
          >
            {tab.label}
          </Link>
        ))}
      </nav>
    </div>
  );
};

export default TabNavigation;
