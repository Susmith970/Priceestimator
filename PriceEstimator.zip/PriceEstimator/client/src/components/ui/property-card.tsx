import { useState } from 'react';
import { Heart, ArrowUp, ArrowDown, Bed, Bath, Square, Clock } from 'lucide-react';
import { Property } from '@shared/schema';
import { formatCurrency, formatTimeAgo } from '@/lib/utils';
import { Badge } from '@/components/ui/badge';

interface PropertyCardProps {
  property: Property;
  onClick?: () => void;
}

const PropertyCard = ({ property, onClick }: PropertyCardProps) => {
  const [isFavorite, setIsFavorite] = useState(false);

  const toggleFavorite = (e: React.MouseEvent) => {
    e.stopPropagation();
    setIsFavorite(!isFavorite);
  };

  const getListingBadge = () => {
    // Convert listingDate to Date object if it's not already
    const listingDateObj = property.listingDate instanceof Date ? 
      property.listingDate : 
      new Date(property.listingDate);
    
    // Check if it's a new listing (less than 3 days old)
    if (new Date().getTime() - listingDateObj.getTime() < 3 * 24 * 60 * 60 * 1000) {
      return <Badge className="absolute top-2 right-2 bg-primary text-white">New Listing</Badge>;
    }
    
    if (property.priceChange && Number(property.priceChange) < 0) {
      return <Badge className="absolute top-2 right-2 bg-amber-500 text-white">Price Reduced</Badge>;
    }
    
    // More badge types could be added here
    
    return null;
  };

  return (
    <div 
      className="bg-white rounded-lg shadow-sm overflow-hidden border border-neutral-200 hover:shadow-md transition-shadow cursor-pointer"
      onClick={onClick}
    >
      <div className="relative">
        <img 
          src={property.imageUrl || "https://images.unsplash.com/photo-1564013799919-ab600027ffc6?auto=format&fit=crop&w=500&h=300&q=80"} 
          alt={property.address} 
          className="w-full h-48 object-cover"
        />
        {getListingBadge()}
        <button 
          className={`absolute top-2 left-2 ${isFavorite ? 'text-amber-500' : 'text-white'} hover:text-amber-500`} 
          aria-label="Save property"
          onClick={toggleFavorite}
        >
          <Heart className={`h-5 w-5 drop-shadow-md ${isFavorite ? 'fill-current' : ''}`} />
        </button>
      </div>
      <div className="p-4">
        <div className="flex justify-between items-start">
          <h3 className="font-semibold text-xl">{formatCurrency(Number(property.price))}</h3>
          {property.priceChange && (
            <div className={`flex items-center text-sm ${Number(property.priceChange) > 0 ? 'text-success' : 'text-error'} font-medium`}>
              {Number(property.priceChange) > 0 ? (
                <ArrowUp className="h-3 w-3 mr-1" />
              ) : (
                <ArrowDown className="h-3 w-3 mr-1" />
              )}
              <span>{Math.abs(Number(property.priceChange))}%</span>
            </div>
          )}
        </div>
        <div className="flex items-center text-sm text-neutral-600 mt-1">
          <Bed className="h-4 w-4 mr-1" />
          <span className="mr-3">{property.bedrooms} beds</span>
          <Bath className="h-4 w-4 mr-1" />
          <span className="mr-3">{property.bathrooms} baths</span>
          <Square className="h-4 w-4 mr-1" />
          <span>{property.squareFeet.toLocaleString()} sqft</span>
        </div>
        <p className="text-neutral-800 mt-2">{property.address}, {property.city}, {property.state} {property.zipCode}</p>
        <div className="flex items-center text-xs text-neutral-600 mt-3">
          <Clock className="h-3 w-3 mr-1" />
          <span>Listed {formatTimeAgo(property.listingDate instanceof Date ? 
            property.listingDate : new Date(property.listingDate))}</span>
        </div>
      </div>
    </div>
  );
};

export default PropertyCard;
