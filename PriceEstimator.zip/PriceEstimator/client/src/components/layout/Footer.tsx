import { Link } from "wouter";
import { Home, Facebook, Twitter, Instagram, Linkedin } from "lucide-react";

const Footer = () => {
  return (
    <footer className="bg-neutral-800 text-neutral-200 py-10 mt-12">
      <div className="container mx-auto px-4">
        <div className="grid md:grid-cols-4 gap-8">
          <div>
            <h3 className="font-semibold text-white mb-4 flex items-center">
              <Home className="h-5 w-5 mr-2" />
              EstateValue
            </h3>
            <p className="text-sm mb-4">
              Real estate pricing platform with powerful estimation tools and comprehensive property data.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-neutral-400 hover:text-white">
                <Facebook size={16} />
              </a>
              <a href="#" className="text-neutral-400 hover:text-white">
                <Twitter size={16} />
              </a>
              <a href="#" className="text-neutral-400 hover:text-white">
                <Instagram size={16} />
              </a>
              <a href="#" className="text-neutral-400 hover:text-white">
                <Linkedin size={16} />
              </a>
            </div>
          </div>
          
          <div>
            <h3 className="font-semibold text-white mb-4">Services</h3>
            <ul className="space-y-2 text-sm">
              <li>
                <Link href="/search" className="text-neutral-400 hover:text-white">
                  Property Search
                </Link>
              </li>
              <li>
                <Link href="/estimate" className="text-neutral-400 hover:text-white">
                  Price Estimator
                </Link>
              </li>
              <li>
                <Link href="/compare" className="text-neutral-400 hover:text-white">
                  Property Comparison
                </Link>
              </li>
              <li>
                <Link href="/analytics" className="text-neutral-400 hover:text-white">
                  Market Trends
                </Link>
              </li>
              <li>
                <Link href="/analytics" className="text-neutral-400 hover:text-white">
                  Neighborhood Analytics
                </Link>
              </li>
            </ul>
          </div>
          
          <div>
            <h3 className="font-semibold text-white mb-4">Company</h3>
            <ul className="space-y-2 text-sm">
              <li>
                <a href="#" className="text-neutral-400 hover:text-white">
                  About Us
                </a>
              </li>
              <li>
                <a href="#" className="text-neutral-400 hover:text-white">
                  Our Team
                </a>
              </li>
              <li>
                <a href="#" className="text-neutral-400 hover:text-white">
                  Careers
                </a>
              </li>
              <li>
                <a href="#" className="text-neutral-400 hover:text-white">
                  Contact Us
                </a>
              </li>
              <li>
                <a href="#" className="text-neutral-400 hover:text-white">
                  Press
                </a>
              </li>
            </ul>
          </div>
          
          <div>
            <h3 className="font-semibold text-white mb-4">Support</h3>
            <ul className="space-y-2 text-sm">
              <li>
                <a href="#" className="text-neutral-400 hover:text-white">
                  Help Center
                </a>
              </li>
              <li>
                <a href="#" className="text-neutral-400 hover:text-white">
                  Privacy Policy
                </a>
              </li>
              <li>
                <a href="#" className="text-neutral-400 hover:text-white">
                  Terms of Service
                </a>
              </li>
              <li>
                <a href="#" className="text-neutral-400 hover:text-white">
                  Cookie Settings
                </a>
              </li>
              <li>
                <a href="#" className="text-neutral-400 hover:text-white">
                  Accessibility
                </a>
              </li>
            </ul>
          </div>
        </div>
        
        <div className="mt-8 pt-8 border-t border-neutral-700 text-sm text-neutral-500">
          <p>© {new Date().getFullYear()} EstateValue. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
