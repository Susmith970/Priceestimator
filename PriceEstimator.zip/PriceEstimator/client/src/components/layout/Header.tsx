import { useState } from "react";
import { Link, useLocation } from "wouter";
import SearchBar from "@/components/ui/search-bar";
import { Home, Menu } from "lucide-react";
import { Button } from "@/components/ui/button";

const Header = () => {
  const [location] = useLocation();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const toggleMobileMenu = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen);
  };

  const isActive = (path: string) => {
    return location === path;
  };

  return (
    <header className="sticky top-0 z-50 bg-white shadow-md">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center">
            <Link href="/" className="flex items-center">
              <Home className="h-6 w-6 text-primary mr-2" />
              <span className="font-semibold text-xl text-primary">EstateValue</span>
            </Link>
          </div>
          
          {/* Desktop Menu */}
          <nav className="hidden md:flex space-x-8">
            <Link href="/" className={`${isActive('/') ? 'text-primary' : 'text-neutral-800 hover:text-primary'} font-medium`}>
              Buy
            </Link>
            <Link href="/search" className={`${isActive('/search') ? 'text-primary' : 'text-neutral-800 hover:text-primary'} font-medium`}>
              Rent
            </Link>
            <Link href="/" className={`${isActive('/sell') ? 'text-primary' : 'text-neutral-800 hover:text-primary'} font-medium`}>
              Sell
            </Link>
            <Link href="/estimate" className={`${isActive('/estimate') ? 'text-primary' : 'text-neutral-800 hover:text-primary'} font-medium`}>
              Estimate
            </Link>
            <Link href="/compare" className={`${isActive('/compare') ? 'text-primary' : 'text-neutral-800 hover:text-primary'} font-medium`}>
              Compare
            </Link>
          </nav>
          
          <div className="flex items-center">
            <Button variant="default" className="hidden md:block">
              Sign In
            </Button>
            
            {/* Mobile menu button */}
            <button 
              className="md:hidden text-neutral-800 hover:text-primary" 
              onClick={toggleMobileMenu}
              aria-label="Toggle menu"
            >
              <Menu className="h-6 w-6" />
            </button>
          </div>
        </div>
        
        {/* Mobile Menu */}
        {isMobileMenuOpen && (
          <div className="md:hidden py-4 border-t border-neutral-200">
            <nav className="flex flex-col space-y-4">
              <Link href="/" className={`${isActive('/') ? 'text-primary' : 'text-neutral-800'} font-medium`}>
                Buy
              </Link>
              <Link href="/search" className={`${isActive('/search') ? 'text-primary' : 'text-neutral-800'} font-medium`}>
                Rent
              </Link>
              <Link href="/" className={`${isActive('/sell') ? 'text-primary' : 'text-neutral-800'} font-medium`}>
                Sell
              </Link>
              <Link href="/estimate" className={`${isActive('/estimate') ? 'text-primary' : 'text-neutral-800'} font-medium`}>
                Estimate
              </Link>
              <Link href="/compare" className={`${isActive('/compare') ? 'text-primary' : 'text-neutral-800'} font-medium`}>
                Compare
              </Link>
              <Button variant="default" className="w-full">
                Sign In
              </Button>
            </nav>
          </div>
        )}
        
        {/* Global Search */}
        <div className="py-4">
          <SearchBar />
        </div>
      </div>
    </header>
  );
};

export default Header;
