import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Property } from '@shared/schema';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Search, X } from 'lucide-react';
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from '@/components/ui/table';
import { formatCurrency, formatNumberWithCommas } from '@/lib/utils';

const PropertyComparison = () => {
  const [selectedProperties, setSelectedProperties] = useState<Property[]>([]);
  const [searchTerms, setSearchTerms] = useState<string[]>(["", "", ""]);
  const [searchResults, setSearchResults] = useState<Property[][]>([[], [], []]);
  
  // Fetch all properties for search results
  const { data: allProperties, isLoading } = useQuery({
    queryKey: ['/api/properties'],
  });
  
  const handleSearch = (index: number, term: string) => {
    setSearchTerms(prev => {
      const updated = [...prev];
      updated[index] = term;
      return updated;
    });
    
    if (term.length > 2 && allProperties) {
      const results = allProperties.filter((property: Property) => 
        property.address.toLowerCase().includes(term.toLowerCase()) ||
        property.city.toLowerCase().includes(term.toLowerCase()) ||
        property.zipCode.includes(term)
      );
      
      setSearchResults(prev => {
        const updated = [...prev];
        updated[index] = results;
        return updated;
      });
    } else {
      setSearchResults(prev => {
        const updated = [...prev];
        updated[index] = [];
        return updated;
      });
    }
  };
  
  const selectProperty = (property: Property, index: number) => {
    setSelectedProperties(prev => {
      const updated = [...prev];
      updated[index] = property;
      return updated;
    });
    
    setSearchResults(prev => {
      const updated = [...prev];
      updated[index] = [];
      return updated;
    });
    
    setSearchTerms(prev => {
      const updated = [...prev];
      updated[index] = property.address;
      return updated;
    });
  };
  
  const removeProperty = (index: number) => {
    setSelectedProperties(prev => {
      const updated = [...prev];
      updated[index] = undefined as any;
      return updated;
    });
    
    setSearchTerms(prev => {
      const updated = [...prev];
      updated[index] = "";
      return updated;
    });
  };
  
  // Only show properties that are actually selected (not undefined)
  const validSelectedProperties = selectedProperties.filter(Boolean);
  
  return (
    <div className="bg-white p-6 rounded-lg shadow-sm border border-neutral-200">
      <h2 className="text-2xl font-semibold mb-6">Compare Properties</h2>
      
      {/* Property Selection */}
      <div className="grid md:grid-cols-3 gap-4 mb-8">
        {[0, 1, 2].map((index) => (
          <div 
            key={index} 
            className={`border border-neutral-200 rounded-lg p-4 ${selectedProperties[index] ? 'bg-neutral-50' : ''}`}
          >
            <h3 className="font-medium mb-2">Property {index + 1}</h3>
            <div className="relative mb-3">
              <Input 
                type="text" 
                placeholder="Search by address"
                value={searchTerms[index]}
                onChange={(e) => handleSearch(index, e.target.value)}
                className="w-full p-2 pr-8 border border-neutral-200 rounded"
              />
              <div className="absolute right-2 top-2 text-neutral-600">
                <Search className="h-4 w-4" />
              </div>
              
              {/* Search Results Dropdown */}
              {searchResults[index].length > 0 && (
                <div className="absolute z-10 mt-1 w-full bg-white shadow-lg rounded-md border border-neutral-200 max-h-60 overflow-y-auto">
                  {searchResults[index].map((property) => (
                    <div 
                      key={property.id}
                      className="p-2 hover:bg-neutral-100 cursor-pointer"
                      onClick={() => selectProperty(property, index)}
                    >
                      <p className="text-sm font-medium">{property.address}</p>
                      <p className="text-xs text-neutral-600">{property.city}, {property.state} {property.zipCode}</p>
                    </div>
                  ))}
                </div>
              )}
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-neutral-600">
                {selectedProperties[index] ? 'Selected' : 'Optional'}
              </span>
              {selectedProperties[index] && (
                <button 
                  className="text-error text-sm flex items-center"
                  onClick={() => removeProperty(index)}
                >
                  <X className="h-3 w-3 mr-1" />
                  Remove
                </button>
              )}
            </div>
          </div>
        ))}
      </div>
      
      {/* Comparison Table */}
      {validSelectedProperties.length >= 2 ? (
        <div className="overflow-x-auto mb-6">
          <Table>
            <TableHeader>
              <TableRow className="bg-neutral-100">
                <TableHead className="font-semibold text-neutral-800">Feature</TableHead>
                {validSelectedProperties.map((property, index) => (
                  <TableHead key={index} className="font-semibold text-neutral-800">
                    {property.address}
                  </TableHead>
                ))}
              </TableRow>
            </TableHeader>
            <TableBody>
              <TableRow>
                <TableCell className="font-medium">Price</TableCell>
                {validSelectedProperties.map((property, index) => (
                  <TableCell key={index}>{formatCurrency(Number(property.price))}</TableCell>
                ))}
              </TableRow>
              <TableRow>
                <TableCell className="font-medium">Price/Sq.Ft</TableCell>
                {validSelectedProperties.map((property, index) => (
                  <TableCell key={index}>
                    ${formatNumberWithCommas(Math.round(Number(property.price) / property.squareFeet))}
                  </TableCell>
                ))}
              </TableRow>
              <TableRow>
                <TableCell className="font-medium">Bedrooms</TableCell>
                {validSelectedProperties.map((property, index) => (
                  <TableCell key={index}>{property.bedrooms}</TableCell>
                ))}
              </TableRow>
              <TableRow>
                <TableCell className="font-medium">Bathrooms</TableCell>
                {validSelectedProperties.map((property, index) => (
                  <TableCell key={index}>{property.bathrooms}</TableCell>
                ))}
              </TableRow>
              <TableRow>
                <TableCell className="font-medium">Square Footage</TableCell>
                {validSelectedProperties.map((property, index) => (
                  <TableCell key={index}>{formatNumberWithCommas(property.squareFeet)}</TableCell>
                ))}
              </TableRow>
              <TableRow>
                <TableCell className="font-medium">Year Built</TableCell>
                {validSelectedProperties.map((property, index) => (
                  <TableCell key={index}>{property.yearBuilt}</TableCell>
                ))}
              </TableRow>
              <TableRow>
                <TableCell className="font-medium">Lot Size</TableCell>
                {validSelectedProperties.map((property, index) => (
                  <TableCell key={index}>
                    {property.lotSize ? `${property.lotSize} acres` : 'N/A'}
                  </TableCell>
                ))}
              </TableRow>
              <TableRow>
                <TableCell className="font-medium">Garage</TableCell>
                {validSelectedProperties.map((property, index) => (
                  <TableCell key={index}>{property.hasGarage ? 'Yes' : 'No'}</TableCell>
                ))}
              </TableRow>
              <TableRow>
                <TableCell className="font-medium">Pool</TableCell>
                {validSelectedProperties.map((property, index) => (
                  <TableCell key={index}>{property.hasPool ? 'Yes' : 'No'}</TableCell>
                ))}
              </TableRow>
              <TableRow>
                <TableCell className="font-medium">School Rating</TableCell>
                {validSelectedProperties.map((property, index) => (
                  <TableCell key={index}>
                    {property.schoolRating ? `${property.schoolRating}/10` : 'N/A'}
                  </TableCell>
                ))}
              </TableRow>
              <TableRow>
                <TableCell className="font-medium">Walk Score</TableCell>
                {validSelectedProperties.map((property, index) => (
                  <TableCell key={index}>
                    {property.walkScore ? `${property.walkScore}/100` : 'N/A'}
                  </TableCell>
                ))}
              </TableRow>
            </TableBody>
          </Table>
        </div>
      ) : (
        <div className="text-center p-8 bg-neutral-50 rounded-lg border border-dashed border-neutral-300 mb-6">
          <p className="text-neutral-600">Select at least two properties to compare them</p>
        </div>
      )}
      
      {validSelectedProperties.length >= 2 && (
        <div className="flex justify-end">
          <Button variant="default">
            Generate PDF Report
          </Button>
        </div>
      )}
    </div>
  );
};

export default PropertyComparison;
