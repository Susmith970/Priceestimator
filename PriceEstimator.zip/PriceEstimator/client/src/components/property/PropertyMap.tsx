import { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Property } from '@shared/schema';
import { 
  MapPin, 
  Plus, 
  Minus, 
  School, 
  Bus, 
  Utensils, 
  ShoppingCart 
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import { ScrollArea } from '@/components/ui/scroll-area';
import { formatCurrency } from '@/lib/utils';

// Mock interface for Leaflet map when it's not available during SSR
interface LeafletMapProps {
  center: [number, number];
  zoom: number;
  properties: Property[];
}

const PropertyMap = () => {
  const [mapLoaded, setMapLoaded] = useState(false);
  const [selectedProperty, setSelectedProperty] = useState<Property | null>(null);
  
  // Fetch properties for the map
  const { data: properties, isLoading } = useQuery({
    queryKey: ['/api/properties'],
  });
  
  // Mock map implementation - in a real implementation, this would use Leaflet
  useEffect(() => {
    if (typeof window !== 'undefined' && !mapLoaded && properties) {
      // Simulate map loading
      const timer = setTimeout(() => {
        setMapLoaded(true);
      }, 500);
      
      return () => clearTimeout(timer);
    }
  }, [properties, mapLoaded]);
  
  const handlePropertyClick = (property: Property) => {
    setSelectedProperty(property);
  };
  
  return (
    <div className="relative h-[600px] rounded-lg overflow-hidden border border-neutral-200">
      {!mapLoaded || isLoading ? (
        // Loading state
        <div className="absolute top-0 left-0 h-full w-full bg-neutral-100 flex items-center justify-center">
          <div className="text-center">
            <div className="flex justify-center mb-2">
              <MapPin className="h-10 w-10 text-neutral-400" />
            </div>
            <p className="text-neutral-400 text-lg">Loading map...</p>
          </div>
        </div>
      ) : (
        // Map display (would be replaced with actual Leaflet map)
        <div className="absolute top-0 left-0 h-full w-full bg-neutral-100 flex items-center justify-center">
          <div className="text-center">
            <MapPin className="h-10 w-10 text-neutral-400 mb-2 mx-auto" />
            <p className="text-neutral-400 text-lg">Interactive Map</p>
            <p className="text-sm text-neutral-600">Map would display property pins, neighborhood boundaries, and points of interest</p>
          </div>
        </div>
      )}
      
      {/* Map Controls */}
      <div className="absolute top-4 right-4 bg-white p-3 rounded-lg shadow-md">
        <div className="flex flex-col space-y-3">
          <Button 
            variant="ghost" 
            size="icon" 
            className="hover:bg-neutral-100 rounded text-neutral-600"
            title="Zoom In"
          >
            <Plus className="h-4 w-4" />
          </Button>
          <Button 
            variant="ghost" 
            size="icon" 
            className="hover:bg-neutral-100 rounded text-neutral-600"
            title="Zoom Out"
          >
            <Minus className="h-4 w-4" />
          </Button>
          <Separator />
          <Button 
            variant="ghost" 
            size="icon" 
            className="hover:bg-neutral-100 rounded text-neutral-600"
            title="Show schools"
          >
            <School className="h-4 w-4" />
          </Button>
          <Button 
            variant="ghost" 
            size="icon" 
            className="hover:bg-neutral-100 rounded text-neutral-600"
            title="Show transit"
          >
            <Bus className="h-4 w-4" />
          </Button>
          <Button 
            variant="ghost" 
            size="icon" 
            className="hover:bg-neutral-100 rounded text-neutral-600"
            title="Show restaurants"
          >
            <Utensils className="h-4 w-4" />
          </Button>
          <Button 
            variant="ghost" 
            size="icon" 
            className="hover:bg-neutral-100 rounded text-neutral-600"
            title="Show grocery"
          >
            <ShoppingCart className="h-4 w-4" />
          </Button>
        </div>
      </div>
      
      {/* Property List Panel */}
      <div className="absolute top-4 left-4 bottom-4 w-80 bg-white rounded-lg shadow-md overflow-hidden">
        <div className="p-3 border-b border-neutral-200">
          <h3 className="font-medium">Properties on Map</h3>
          <p className="text-sm text-neutral-600">
            {properties ? properties.length : 0} properties
          </p>
        </div>
        <ScrollArea className="h-[calc(100%-57px)]">
          {properties && properties.map((property: Property) => (
            <div 
              key={property.id}
              onClick={() => handlePropertyClick(property)}
              className={`p-3 border-b border-neutral-200 hover:bg-neutral-50 cursor-pointer ${
                selectedProperty?.id === property.id ? 'bg-neutral-50' : ''
              }`}
            >
              <div className="flex">
                <img 
                  src={property.imageUrl || "https://images.unsplash.com/photo-1564013799919-ab600027ffc6?auto=format&fit=crop&w=80&h=60&q=80"} 
                  alt={property.address} 
                  className="w-20 h-16 object-cover rounded"
                />
                <div className="ml-3">
                  <p className="font-medium">{formatCurrency(Number(property.price))}</p>
                  <p className="text-sm text-neutral-600">
                    {property.bedrooms} bd | {property.bathrooms} ba | {property.squareFeet.toLocaleString()} sqft
                  </p>
                  <p className="text-xs text-neutral-700 truncate">
                    {property.address}, {property.city}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </ScrollArea>
      </div>
    </div>
  );
};

export default PropertyMap;
