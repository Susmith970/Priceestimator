import { useState } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { insertPriceEstimateSchema } from '@shared/schema';
import { PriceEstimate } from '@shared/schema';
import { Card, CardContent } from '@/components/ui/card';
import { 
  Form, 
  FormControl, 
  FormField, 
  FormItem, 
  FormLabel, 
  FormMessage 
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import { 
  formatCurrency, 
  formatNumberWithCommas 
} from '@/lib/utils';

// Extend the schema with validation rules
const formSchema = insertPriceEstimateSchema.extend({
  address: z.string().min(5, {
    message: 'Address must be at least 5 characters',
  }),
  squareFeet: z.coerce.number().min(100, {
    message: 'Square footage must be at least 100',
  }),
  bedrooms: z.coerce.number().min(1, {
    message: 'Number of bedrooms must be at least 1',
  }),
  bathrooms: z.coerce.number().min(1, {
    message: 'Number of bathrooms must be at least 1',
  }),
  yearBuilt: z.coerce.number().min(1800, {
    message: 'Year built must be at least 1800',
  }).max(new Date().getFullYear(), {
    message: `Year built cannot be in the future`,
  }),
});

// Define the form values type
type FormValues = z.infer<typeof formSchema>;

const PriceEstimator = () => {
  const [estimate, setEstimate] = useState<PriceEstimate | null>(null);
  
  // Form setup with react-hook-form
  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      address: '',
      squareFeet: 1850,
      bedrooms: 3,
      bathrooms: 2,
      yearBuilt: 2005,
      propertyType: 'Single Family Home',
      // These fields have default values set by the schema
      estimatedPrice: 0,
      minRange: 0,
      maxRange: 0,
      confidenceScore: 0,
      createdAt: new Date(),
    },
  });
  
  // Mutation for submitting the form
  const mutation = useMutation({
    mutationFn: async (data: FormValues) => {
      const response = await apiRequest('POST', '/api/estimate', data);
      return response.json();
    },
    onSuccess: (data: PriceEstimate) => {
      setEstimate(data);
    },
  });
  
  // Fetch neighborhood data for market trends
  const { data: neighborhoods } = useQuery({
    queryKey: ['/api/neighborhoods'],
    enabled: !!estimate, // Only fetch when an estimate exists
  });
  
  const neighborhood = neighborhoods?.[0]; // Get the first neighborhood
  
  // Form submission handler
  const onSubmit = (data: FormValues) => {
    mutation.mutate(data);
  };
  
  return (
    <div className="bg-white p-6 rounded-lg shadow-sm border border-neutral-200 max-w-4xl mx-auto">
      <h2 className="text-2xl font-semibold mb-6">Property Price Estimator</h2>
      
      <div className="grid md:grid-cols-2 gap-8">
        <div>
          <h3 className="font-semibold text-lg mb-4">Property Details</h3>
          
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              {/* Address Input */}
              <FormField
                control={form.control}
                name="address"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Property Address</FormLabel>
                    <FormControl>
                      <Input 
                        placeholder="Enter property address" 
                        {...field} 
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              {/* Property Features */}
              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="bedrooms"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Bedrooms</FormLabel>
                      <Select 
                        onValueChange={(value) => field.onChange(parseInt(value))}
                        defaultValue={field.value.toString()}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select bedrooms" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="1">1</SelectItem>
                          <SelectItem value="2">2</SelectItem>
                          <SelectItem value="3">3</SelectItem>
                          <SelectItem value="4">4</SelectItem>
                          <SelectItem value="5">5+</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="bathrooms"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Bathrooms</FormLabel>
                      <Select 
                        onValueChange={(value) => field.onChange(parseFloat(value))}
                        defaultValue={field.value.toString()}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select bathrooms" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="1">1</SelectItem>
                          <SelectItem value="1.5">1.5</SelectItem>
                          <SelectItem value="2">2</SelectItem>
                          <SelectItem value="2.5">2.5</SelectItem>
                          <SelectItem value="3">3</SelectItem>
                          <SelectItem value="3.5">3.5+</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              
              {/* Square Footage */}
              <FormField
                control={form.control}
                name="squareFeet"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Square Footage</FormLabel>
                    <FormControl>
                      <Input 
                        type="number" 
                        {...field} 
                        onChange={(e) => field.onChange(e.target.valueAsNumber)}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              {/* Property Type */}
              <FormField
                control={form.control}
                name="propertyType"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Property Type</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select property type" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="Single Family Home">Single Family Home</SelectItem>
                        <SelectItem value="Condo/Townhouse">Condo/Townhouse</SelectItem>
                        <SelectItem value="Multi-Family">Multi-Family</SelectItem>
                        <SelectItem value="Land">Land</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              {/* Year Built */}
              <FormField
                control={form.control}
                name="yearBuilt"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Year Built</FormLabel>
                    <FormControl>
                      <Input 
                        type="number" 
                        {...field} 
                        onChange={(e) => field.onChange(e.target.valueAsNumber)}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              {/* Additional Features */}
              <div>
                <p className="block text-sm font-medium text-neutral-600 mb-1">Additional Features</p>
                <div className="grid grid-cols-2 gap-2">
                  <div className="flex items-center text-sm">
                    <Checkbox id="garage" className="mr-2 text-primary" />
                    <Label htmlFor="garage">Garage</Label>
                  </div>
                  <div className="flex items-center text-sm">
                    <Checkbox id="pool" className="mr-2 text-primary" />
                    <Label htmlFor="pool">Pool</Label>
                  </div>
                  <div className="flex items-center text-sm">
                    <Checkbox id="fireplace" className="mr-2 text-primary" />
                    <Label htmlFor="fireplace">Fireplace</Label>
                  </div>
                  <div className="flex items-center text-sm">
                    <Checkbox id="renovatedKitchen" className="mr-2 text-primary" />
                    <Label htmlFor="renovatedKitchen">Renovated Kitchen</Label>
                  </div>
                  <div className="flex items-center text-sm">
                    <Checkbox id="basement" className="mr-2 text-primary" />
                    <Label htmlFor="basement">Basement</Label>
                  </div>
                  <div className="flex items-center text-sm">
                    <Checkbox id="solarPanels" className="mr-2 text-primary" />
                    <Label htmlFor="solarPanels">Solar Panels</Label>
                  </div>
                </div>
              </div>
              
              <Button 
                type="submit" 
                className="w-full"
                disabled={mutation.isPending}
              >
                {mutation.isPending ? 'Calculating...' : 'Calculate Estimate'}
              </Button>
            </form>
          </Form>
        </div>
        
        <div>
          {/* Estimated Price Result */}
          {estimate ? (
            <div className="bg-neutral-100 p-6 rounded-lg mb-6">
              <h3 className="text-center text-lg font-medium text-neutral-600 mb-2">Estimated Property Value</h3>
              <p className="text-center text-4xl font-bold text-primary mb-3">
                {formatCurrency(Number(estimate.estimatedPrice))}
              </p>
              <p className="text-center text-sm text-neutral-600">
                Value range: {formatCurrency(Number(estimate.minRange))} - {formatCurrency(Number(estimate.maxRange))}
              </p>
              
              <div className="mt-6">
                <p className="text-sm text-center text-neutral-600 mb-2">Confidence Score</p>
                <div className="h-4 bg-neutral-200 rounded-full overflow-hidden">
                  <div 
                    className="h-full bg-success rounded-full" 
                    style={{ width: `${estimate.confidenceScore}%` }}
                  ></div>
                </div>
                <p className="text-xs text-right mt-1 text-neutral-600">{estimate.confidenceScore}% confidence</p>
              </div>
            </div>
          ) : (
            <div className="bg-neutral-100 p-6 rounded-lg mb-6 flex flex-col items-center justify-center">
              <h3 className="text-center text-lg font-medium text-neutral-600 mb-2">Estimated Property Value</h3>
              <p className="text-center text-neutral-400 mb-4">Fill in property details and click Calculate to see your estimate</p>
              
              <div className="w-full h-4 bg-neutral-200 rounded-full mt-6"></div>
              <p className="text-xs text-right mt-1 text-neutral-600 w-full">Confidence score</p>
            </div>
          )}
          
          {/* Neighborhood Market Trends */}
          <div>
            <h3 className="font-semibold text-lg mb-2">Neighborhood Market Trends</h3>
            <p className="text-sm text-neutral-600 mb-4">
              {neighborhood ? `Based on data from properties in ${neighborhood.name}, ${neighborhood.city}, ${neighborhood.state} ${neighborhood.zipCode}`
              : 'Based on market data from similar properties'}
            </p>
            
            <div className="space-y-4">
              {/* Average Price */}
              <div className="flex justify-between items-center">
                <p className="text-sm font-medium">Average Price</p>
                <p className="font-semibold">
                  {neighborhood ? formatCurrency(Number(neighborhood.averagePrice)) : '$720,500'}
                </p>
              </div>
              
              {/* Price per sq ft */}
              <div className="flex justify-between items-center">
                <p className="text-sm font-medium">Price per sq ft</p>
                <p className="font-semibold">
                  {neighborhood ? `$${formatNumberWithCommas(Number(neighborhood.pricePerSqFt))}` : '$386'}
                </p>
              </div>
              
              {/* Annual Appreciation */}
              <div className="flex justify-between items-center">
                <p className="text-sm font-medium">Annual Appreciation</p>
                <p className="font-semibold text-success">
                  {neighborhood ? `+${neighborhood.annualAppreciation}%` : '+4.2%'}
                </p>
              </div>
              
              {/* Market Trend */}
              <div className="flex justify-between items-center">
                <p className="text-sm font-medium">Market Heat</p>
                <div className="flex items-center">
                  <span className="text-amber-500 font-semibold mr-1">
                    {neighborhood ? neighborhood.marketHeat : 'Warm'}
                  </span>
                  <svg 
                    xmlns="http://www.w3.org/2000/svg" 
                    width="16" 
                    height="16" 
                    viewBox="0 0 24 24" 
                    fill="none" 
                    stroke="currentColor" 
                    strokeWidth="2" 
                    strokeLinecap="round" 
                    strokeLinejoin="round" 
                    className="text-amber-500"
                  >
                    <path d="M8.5 14.5A2.5 2.5 0 0 0 11 12c0-1.38-.5-2-1-3-1.072-2.143-.224-4.054 2-6 .5 2.5 2 4.9 4 6.5 2 1.6 3 3.5 3 5.5a7 7 0 1 1-14 0c0-1.153.433-2.294 1-3a2.5 2.5 0 0 0 2.5 2.5z" />
                  </svg>
                </div>
              </div>
            </div>
            
            <div className="mt-6">
              <Button variant="default" className="w-full">
                Generate Full Report
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PriceEstimator;
