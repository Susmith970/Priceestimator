import { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { useLocation } from 'wouter';
import { Property } from '@shared/schema';
import FilterSidebar, { FilterValues } from '@/components/ui/filter-sidebar';
import PropertyCard from '@/components/ui/property-card';
import TabNavigation from '@/components/ui/tab-navigation';
import Pagination from '@/components/ui/pagination';
import PropertyMap from '@/components/property/PropertyMap';
import { Button } from '@/components/ui/button';
import { List, MapPin } from 'lucide-react';

const PropertySearch = () => {
  const [location, setLocation] = useLocation();
  const [showMap, setShowMap] = useState(false);
  const [page, setPage] = useState(1);
  const [sortOption, setSortOption] = useState('recommended');
  const [filters, setFilters] = useState<FilterValues>({
    priceMin: '',
    priceMax: '',
    propertyTypes: ['Single Family Home', 'Condo/Townhouse'],
    bedrooms: '1+',
    bathrooms: '2+',
    sizeMin: '',
    sizeMax: '',
    hasGarage: false,
    hasPool: false,
    hasFireplace: false,
    hasRenovatedKitchen: false,
    hasBasement: false,
    hasSolarPanels: false,
  });
  
  // Extract search query from URL if present
  useEffect(() => {
    const params = new URLSearchParams(location.split('?')[1]);
    const query = params.get('query');
    
    if (query) {
      // Update filter state based on search query
      setFilters(prev => ({
        ...prev,
        searchQuery: query
      }));
    }
  }, [location]);
  
  // Get the min bedrooms as number from selected filter
  const getMinBedrooms = () => {
    if (filters.bedrooms === 'any') return undefined;
    return parseInt(filters.bedrooms.replace('+', ''));
  };
  
  // Get the min bathrooms as number from selected filter
  const getMinBathrooms = () => {
    if (filters.bathrooms === 'any') return undefined;
    return parseFloat(filters.bathrooms.replace('+', ''));
  };
  
  // Fetch properties based on filters
  const { data: properties, isLoading } = useQuery({
    queryKey: ['/api/properties', filters, page, sortOption],
    queryFn: async () => {
      // Build query params
      const params = new URLSearchParams();
      
      if (filters.priceMin) params.append('minPrice', filters.priceMin);
      if (filters.priceMax) params.append('maxPrice', filters.priceMax);
      
      const minBedrooms = getMinBedrooms();
      if (minBedrooms) params.append('minBedrooms', minBedrooms.toString());
      
      const minBathrooms = getMinBathrooms();
      if (minBathrooms) params.append('minBathrooms', minBathrooms.toString());
      
      if (filters.sizeMin) params.append('minSquareFeet', filters.sizeMin);
      if (filters.sizeMax) params.append('maxSquareFeet', filters.sizeMax);
      
      if (filters.propertyTypes && filters.propertyTypes.length > 0) {
        params.append('propertyTypes', filters.propertyTypes.join(','));
      }
      
      if (filters.hasGarage) params.append('hasGarage', 'true');
      if (filters.hasPool) params.append('hasPool', 'true');
      if (filters.hasFireplace) params.append('hasFireplace', 'true');
      if (filters.hasRenovatedKitchen) params.append('hasRenovatedKitchen', 'true');
      if (filters.hasBasement) params.append('hasBasement', 'true');
      if (filters.hasSolarPanels) params.append('hasSolarPanels', 'true');
      
      // Fetch properties with query params
      const response = await fetch(`/api/properties?${params.toString()}`);
      
      if (!response.ok) {
        throw new Error('Failed to fetch properties');
      }
      
      return response.json();
    }
  });
  
  // Handle filter changes
  const handleFilterChange = (newFilters: FilterValues) => {
    setFilters(newFilters);
  };
  
  // Apply filters
  const applyFilters = () => {
    // Reset to first page when filters change
    setPage(1);
    
    // Refetch data with new filters
    // This happens automatically due to queryKey dependency on filters
  };
  
  // Sort properties based on sort option
  const sortProperties = (properties: Property[]) => {
    if (!properties) return [];
    
    const sortedProperties = [...properties];
    
    switch (sortOption) {
      case 'price-asc':
        return sortedProperties.sort((a, b) => Number(a.price) - Number(b.price));
      case 'price-desc':
        return sortedProperties.sort((a, b) => Number(b.price) - Number(a.price));
      case 'newest':
        return sortedProperties.sort((a, b) => {
          const dateA = a.listingDate instanceof Date ? a.listingDate : new Date(a.listingDate);
          const dateB = b.listingDate instanceof Date ? b.listingDate : new Date(b.listingDate);
          return dateB.getTime() - dateA.getTime();
        });
      default:
        return sortedProperties; // Default: recommended
    }
  };
  
  // Get active tab
  const tabs = [
    { label: 'Property Search', href: '/search', isActive: true },
    { label: 'Price Estimator', href: '/estimate', isActive: false },
    { label: 'Compare Properties', href: '/compare', isActive: false },
    { label: 'Neighborhood Analytics', href: '/analytics', isActive: false },
  ];
  
  // Calculate total pages
  const totalPages = properties ? Math.ceil(properties.length / 6) : 1;
  
  // Get current page items
  const getCurrentPageItems = () => {
    if (!properties) return [];
    
    const sortedProperties = sortProperties(properties);
    const startIndex = (page - 1) * 6;
    const endIndex = startIndex + 6;
    
    return sortedProperties.slice(startIndex, endIndex);
  };
  
  const currentPageItems = getCurrentPageItems();
  
  return (
    <div className="container mx-auto px-4 py-6">
      <TabNavigation tabs={tabs} />
      
      <div className="md:flex gap-6">
        {/* Filter Sidebar */}
        <div className="md:w-1/4 mb-6 md:mb-0">
          <FilterSidebar 
            filters={filters}
            onChange={handleFilterChange}
            onApply={applyFilters}
          />
        </div>
        
        {/* Property Listing Content */}
        <div className="md:w-3/4">
          {/* Results Controls */}
          <div className="flex justify-between items-center mb-4">
            <p className="text-neutral-600">
              <span className="font-medium">{properties ? properties.length : 0}</span> homes
            </p>
            <div className="flex items-center gap-3">
              <div className="flex items-center border border-neutral-200 rounded overflow-hidden">
                <Button
                  variant={!showMap ? 'default' : 'ghost'}
                  size="sm"
                  className="px-3 py-1 h-auto rounded-none"
                  onClick={() => setShowMap(false)}
                >
                  <List className="h-4 w-4" />
                </Button>
                <Button
                  variant={showMap ? 'default' : 'ghost'}
                  size="sm"
                  className="px-3 py-1 h-auto rounded-none"
                  onClick={() => setShowMap(true)}
                >
                  <MapPin className="h-4 w-4" />
                </Button>
              </div>
              <select 
                className="border border-neutral-200 rounded p-1 text-sm"
                value={sortOption}
                onChange={(e) => setSortOption(e.target.value)}
              >
                <option value="recommended">Sort: Recommended</option>
                <option value="price-asc">Price: Low to High</option>
                <option value="price-desc">Price: High to Low</option>
                <option value="newest">Newest</option>
              </select>
            </div>
          </div>
          
          {/* Display Map View or Property Grid */}
          {showMap ? (
            <PropertyMap />
          ) : (
            <>
              {/* Property Grid */}
              {isLoading ? (
                // Loading skeletons
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {Array(6).fill(0).map((_, i) => (
                    <div key={i} className="bg-white rounded-lg shadow-sm overflow-hidden border border-neutral-200 p-4">
                      <div className="w-full h-48 bg-neutral-200 rounded-md mb-4 animate-pulse"></div>
                      <div className="h-6 bg-neutral-200 rounded-md mb-2 animate-pulse"></div>
                      <div className="h-4 bg-neutral-200 rounded-md mb-2 w-3/4 animate-pulse"></div>
                      <div className="h-4 bg-neutral-200 rounded-md w-1/2 animate-pulse"></div>
                    </div>
                  ))}
                </div>
              ) : properties && properties.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {currentPageItems.map((property: Property) => (
                    <PropertyCard
                      key={property.id}
                      property={property}
                      onClick={() => {/* Navigate to property detail */}}
                    />
                  ))}
                </div>
              ) : (
                <div className="text-center p-12 bg-neutral-50 rounded-lg border border-dashed border-neutral-300">
                  <p className="text-neutral-600">No properties match your search criteria</p>
                  <Button 
                    variant="link" 
                    className="mt-2"
                    onClick={() => setFilters({
                      priceMin: '',
                      priceMax: '',
                      propertyTypes: ['Single Family Home', 'Condo/Townhouse'],
                      bedrooms: 'any',
                      bathrooms: 'any',
                      sizeMin: '',
                      sizeMax: '',
                    })}
                  >
                    Reset Filters
                  </Button>
                </div>
              )}
              
              {/* Pagination */}
              {properties && properties.length > 6 && (
                <Pagination 
                  currentPage={page}
                  totalPages={totalPages}
                  onPageChange={setPage}
                />
              )}
            </>
          )}
        </div>
      </div>
    </div>
  );
};

export default PropertySearch;
