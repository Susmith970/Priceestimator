import { useEffect } from 'react';
import { useLocation } from 'wouter';
import PriceEstimator from '@/components/property/PriceEstimator';
import TabNavigation from '@/components/ui/tab-navigation';

const PriceEstimatorPage = () => {
  const [location] = useLocation();
  
  // Get active tab
  const tabs = [
    { label: 'Property Search', href: '/search', isActive: false },
    { label: 'Price Estimator', href: '/estimate', isActive: true },
    { label: 'Compare Properties', href: '/compare', isActive: false },
    { label: 'Neighborhood Analytics', href: '/analytics', isActive: false },
  ];
  
  return (
    <div className="container mx-auto px-4 py-6">
      <TabNavigation tabs={tabs} />
      <PriceEstimator />
    </div>
  );
};

export default PriceEstimatorPage;
