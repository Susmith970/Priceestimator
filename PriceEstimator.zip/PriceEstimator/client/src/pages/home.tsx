import { useQuery } from '@tanstack/react-query';
import { Link } from 'wouter';
import { Property } from '@shared/schema';
import PropertyCard from '@/components/ui/property-card';
import { Button } from '@/components/ui/button';
import { ChevronRight } from 'lucide-react';

const Home = () => {
  // Fetch featured properties for the homepage
  const { data: properties, isLoading } = useQuery({
    queryKey: ['/api/properties'],
  });

  return (
    <div className="container mx-auto px-4 py-12">
      {/* Hero Section */}
      <div className="bg-gradient-to-r from-primary to-blue-700 rounded-xl py-16 px-8 mb-12 text-white text-center">
        <h1 className="text-4xl md:text-5xl font-bold mb-4">Find Your Perfect Property</h1>
        <p className="text-xl mb-8 max-w-2xl mx-auto">
          Browse thousands of properties and discover your dream home with our powerful pricing tools.
        </p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Link href="/search">
            <Button size="lg" variant="secondary" className="px-6">
              Browse Properties
            </Button>
          </Link>
          <Link href="/estimate">
            <Button size="lg" variant="outline" className="bg-transparent border-white text-white px-6 hover:bg-white hover:text-primary">
              Estimate Property Value
            </Button>
          </Link>
        </div>
      </div>

      {/* Featured Properties */}
      <div className="mb-12">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-semibold">Featured Properties</h2>
          <Link href="/search">
            <Button variant="ghost" className="text-primary flex items-center">
              View all <ChevronRight className="h-4 w-4 ml-1" />
            </Button>
          </Link>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {isLoading ? (
            // Loading skeletons
            Array(3).fill(0).map((_, i) => (
              <div key={i} className="bg-white rounded-lg shadow-sm overflow-hidden border border-neutral-200 p-4">
                <div className="w-full h-48 bg-neutral-200 rounded-md mb-4 animate-pulse"></div>
                <div className="h-6 bg-neutral-200 rounded-md mb-2 animate-pulse"></div>
                <div className="h-4 bg-neutral-200 rounded-md mb-2 w-3/4 animate-pulse"></div>
                <div className="h-4 bg-neutral-200 rounded-md w-1/2 animate-pulse"></div>
              </div>
            ))
          ) : (
            properties?.slice(0, 3).map((property: Property) => (
              <PropertyCard
                key={property.id}
                property={property}
                onClick={() => {/* Navigate to property detail */}}
              />
            ))
          )}
        </div>
      </div>

      {/* Services Section */}
      <div className="mb-12">
        <h2 className="text-2xl font-semibold mb-6 text-center">Our Services</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="bg-white p-6 rounded-lg shadow-sm border border-neutral-200 text-center">
            <div className="mb-4 bg-blue-50 p-4 rounded-full w-16 h-16 flex items-center justify-center mx-auto">
              <svg 
                xmlns="http://www.w3.org/2000/svg" 
                fill="none" 
                viewBox="0 0 24 24" 
                strokeWidth={1.5} 
                stroke="currentColor" 
                className="w-8 h-8 text-primary"
              >
                <path strokeLinecap="round" strokeLinejoin="round" d="M15 10.5a3 3 0 1 1-6 0 3 3 0 0 1 6 0Z" />
                <path strokeLinecap="round" strokeLinejoin="round" d="M19.5 10.5c0 7.142-7.5 11.25-7.5 11.25S4.5 17.642 4.5 10.5a7.5 7.5 0 1 1 15 0Z" />
              </svg>
            </div>
            <h3 className="text-xl font-semibold mb-2">Property Search</h3>
            <p className="text-neutral-600 mb-4">
              Find your dream home with our advanced search tools. Filter by price, location, amenities and more.
            </p>
            <Link href="/search">
              <Button variant="link" className="text-primary">
                Start Searching
              </Button>
            </Link>
          </div>
          
          <div className="bg-white p-6 rounded-lg shadow-sm border border-neutral-200 text-center">
            <div className="mb-4 bg-blue-50 p-4 rounded-full w-16 h-16 flex items-center justify-center mx-auto">
              <svg 
                xmlns="http://www.w3.org/2000/svg" 
                fill="none" 
                viewBox="0 0 24 24" 
                strokeWidth={1.5} 
                stroke="currentColor" 
                className="w-8 h-8 text-primary"
              >
                <path strokeLinecap="round" strokeLinejoin="round" d="M12 6v12m-3-2.818.879.659c1.171.879 3.07.879 4.242 0 1.172-.879 1.172-2.303 0-3.182C13.536 12.219 12.768 12 12 12c-.725 0-1.45-.22-2.003-.659-1.106-.879-1.106-2.303 0-3.182s2.9-.879 4.006 0l.415.33M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z" />
              </svg>
            </div>
            <h3 className="text-xl font-semibold mb-2">Price Estimation</h3>
            <p className="text-neutral-600 mb-4">
              Get an accurate estimate of your property's value based on market data and property features.
            </p>
            <Link href="/estimate">
              <Button variant="link" className="text-primary">
                Estimate Value
              </Button>
            </Link>
          </div>
          
          <div className="bg-white p-6 rounded-lg shadow-sm border border-neutral-200 text-center">
            <div className="mb-4 bg-blue-50 p-4 rounded-full w-16 h-16 flex items-center justify-center mx-auto">
              <svg 
                xmlns="http://www.w3.org/2000/svg" 
                fill="none" 
                viewBox="0 0 24 24" 
                strokeWidth={1.5} 
                stroke="currentColor" 
                className="w-8 h-8 text-primary"
              >
                <path strokeLinecap="round" strokeLinejoin="round" d="M3 13.125C3 12.504 3.504 12 4.125 12h2.25c.621 0 1.125.504 1.125 1.125v6.75C7.5 20.496 6.996 21 6.375 21h-2.25A1.125 1.125 0 0 1 3 19.875v-6.75ZM9.75 8.625c0-.621.504-1.125 1.125-1.125h2.25c.621 0 1.125.504 1.125 1.125v11.25c0 .621-.504 1.125-1.125 1.125h-2.25a1.125 1.125 0 0 1-1.125-1.125V8.625ZM16.5 4.125c0-.621.504-1.125 1.125-1.125h2.25C20.496 3 21 3.504 21 4.125v15.75c0 .621-.504 1.125-1.125 1.125h-2.25a1.125 1.125 0 0 1-1.125-1.125V4.125Z" />
              </svg>
            </div>
            <h3 className="text-xl font-semibold mb-2">Market Analytics</h3>
            <p className="text-neutral-600 mb-4">
              Explore neighborhood data, market trends, and investment opportunities with our analytics tools.
            </p>
            <Link href="/analytics">
              <Button variant="link" className="text-primary">
                View Analytics
              </Button>
            </Link>
          </div>
        </div>
      </div>

      {/* Call to Action */}
      <div className="bg-neutral-100 rounded-xl py-12 px-8 text-center">
        <h2 className="text-2xl font-semibold mb-4">Ready to find your perfect property?</h2>
        <p className="text-neutral-600 mb-6 max-w-2xl mx-auto">
          Join thousands of satisfied customers who found their dream homes through our platform.
        </p>
        <Link href="/search">
          <Button size="lg" variant="default" className="px-8">
            Get Started
          </Button>
        </Link>
      </div>
    </div>
  );
};

export default Home;
