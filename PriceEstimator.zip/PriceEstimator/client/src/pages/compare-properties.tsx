import { useLocation } from 'wouter';
import PropertyComparison from '@/components/property/PropertyComparison';
import TabNavigation from '@/components/ui/tab-navigation';

const ComparePropertiesPage = () => {
  const [location] = useLocation();
  
  // Get active tab
  const tabs = [
    { label: 'Property Search', href: '/search', isActive: false },
    { label: 'Price Estimator', href: '/estimate', isActive: false },
    { label: 'Compare Properties', href: '/compare', isActive: true },
    { label: 'Neighborhood Analytics', href: '/analytics', isActive: false },
  ];
  
  return (
    <div className="container mx-auto px-4 py-6">
      <TabNavigation tabs={tabs} />
      <PropertyComparison />
    </div>
  );
};

export default ComparePropertiesPage;
