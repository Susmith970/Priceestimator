import { useQuery } from '@tanstack/react-query';
import { useLocation } from 'wouter';
import TabNavigation from '@/components/ui/tab-navigation';
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle, 
  CardDescription 
} from "@/components/ui/card";
import {
  BarChart,
  Bar,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell
} from 'recharts';
import { formatCurrency, formatNumberWithCommas } from '@/lib/utils';
import { Neighborhood } from '@shared/schema';
import { Flame, TrendingUp, Home, DollarSign } from 'lucide-react';

const NeighborhoodAnalytics = () => {
  const [location] = useLocation();
  
  // Get active tab
  const tabs = [
    { label: 'Property Search', href: '/search', isActive: false },
    { label: 'Price Estimator', href: '/estimate', isActive: false },
    { label: 'Compare Properties', href: '/compare', isActive: false },
    { label: 'Neighborhood Analytics', href: '/analytics', isActive: true },
  ];
  
  // Fetch neighborhood data
  const { data: neighborhoods, isLoading } = useQuery({
    queryKey: ['/api/neighborhoods'],
  });
  
  // Mock price history data for neighborhood trend chart
  const priceHistoryData = [
    { month: 'Jan', price: 680000 },
    { month: 'Feb', price: 685000 },
    { month: 'Mar', price: 690000 },
    { month: 'Apr', price: 695000 },
    { month: 'May', price: 705000 },
    { month: 'Jun', price: 710000 },
    { month: 'Jul', price: 715000 },
    { month: 'Aug', price: 720500 }
  ];
  
  // Property type distribution for pie chart
  const propertyTypeData = [
    { name: 'Single Family', value: 65 },
    { name: 'Condos', value: 20 },
    { name: 'Townhomes', value: 10 },
    { name: 'Multi-Family', value: 5 }
  ];
  
  // Comparable neighborhoods data
  const comparableNeighborhoods = [
    { name: 'Downtown Pleasantville', value: 720500 },
    { name: 'East Pleasantville', value: 680000 },
    { name: 'West Pleasantville', value: 750000 },
    { name: 'North Hills', value: 810000 },
    { name: 'South Valley', value: 650000 }
  ];
  
  // Pie chart colors
  const COLORS = ['#2563eb', '#0f766e', '#f59e0b', '#64748b'];
  
  // Selected neighborhood (first one from API or fallback)
  const selectedNeighborhood: Neighborhood = neighborhoods?.[0] || {
    name: 'Downtown Pleasantville',
    city: 'Pleasantville',
    state: 'CA',
    zipCode: '91234',
    averagePrice: 720500,
    pricePerSqFt: 386,
    annualAppreciation: 4.2,
    marketHeat: 'Warm'
  };
  
  return (
    <div className="container mx-auto px-4 py-6">
      <TabNavigation tabs={tabs} />
      
      <div className="mb-6">
        <h1 className="text-2xl font-bold mb-2">Neighborhood Analytics</h1>
        <p className="text-neutral-600">
          Explore market trends and property data for {selectedNeighborhood.name}, {selectedNeighborhood.city}, {selectedNeighborhood.state}
        </p>
      </div>
      
      {/* Stats Overview */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center space-x-2">
              <div className="p-2 bg-blue-100 rounded-full">
                <DollarSign className="h-6 w-6 text-primary" />
              </div>
              <div>
                <p className="text-sm font-medium text-neutral-600">Average Price</p>
                <p className="text-2xl font-bold">{formatCurrency(Number(selectedNeighborhood.averagePrice))}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center space-x-2">
              <div className="p-2 bg-teal-100 rounded-full">
                <Home className="h-6 w-6 text-teal-600" />
              </div>
              <div>
                <p className="text-sm font-medium text-neutral-600">Price per sq ft</p>
                <p className="text-2xl font-bold">${formatNumberWithCommas(Number(selectedNeighborhood.pricePerSqFt))}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center space-x-2">
              <div className="p-2 bg-green-100 rounded-full">
                <TrendingUp className="h-6 w-6 text-green-600" />
              </div>
              <div>
                <p className="text-sm font-medium text-neutral-600">Annual Appreciation</p>
                <p className="text-2xl font-bold text-success">+{selectedNeighborhood.annualAppreciation}%</p>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center space-x-2">
              <div className="p-2 bg-amber-100 rounded-full">
                <Flame className="h-6 w-6 text-amber-500" />
              </div>
              <div>
                <p className="text-sm font-medium text-neutral-600">Market Heat</p>
                <p className="text-2xl font-bold text-amber-500">{selectedNeighborhood.marketHeat}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
      
      {/* Charts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
        {/* Price Trend Chart */}
        <Card>
          <CardHeader>
            <CardTitle>Price Trends (Last 8 Months)</CardTitle>
            <CardDescription>Historical average property values in {selectedNeighborhood.name}</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart
                  data={priceHistoryData}
                  margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                >
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="month" />
                  <YAxis 
                    tickFormatter={(value) => `$${value/1000}k`}
                    domain={['dataMin - 20000', 'dataMax + 20000']} 
                  />
                  <Tooltip 
                    formatter={(value) => formatCurrency(Number(value))}
                    labelFormatter={(label) => `Month: ${label}`}
                  />
                  <Legend />
                  <Line 
                    type="monotone" 
                    dataKey="price" 
                    name="Avg. Price"
                    stroke="#2563eb" 
                    strokeWidth={2}
                    activeDot={{ r: 8 }} 
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
        
        {/* Property Types Chart */}
        <Card>
          <CardHeader>
            <CardTitle>Property Type Distribution</CardTitle>
            <CardDescription>Breakdown of housing types in {selectedNeighborhood.name}</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={propertyTypeData}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={({name, percent}) => `${name}: ${(percent * 100).toFixed(0)}%`}
                    outerRadius={80}
                    fill="#8884d8"
                    dataKey="value"
                  >
                    {propertyTypeData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip formatter={(value) => `${value}%`} />
                  <Legend />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </div>
      
      {/* Neighborhood Comparison */}
      <Card className="mb-6">
        <CardHeader>
          <CardTitle>Neighborhood Price Comparison</CardTitle>
          <CardDescription>How {selectedNeighborhood.name} compares to nearby areas</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart
                data={comparableNeighborhoods}
                margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
              >
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" />
                <YAxis 
                  tickFormatter={(value) => `$${value/1000}k`}
                  domain={['dataMin - 50000', 'dataMax + 50000']} 
                />
                <Tooltip 
                  formatter={(value) => formatCurrency(Number(value))}
                  labelFormatter={(label) => `Neighborhood: ${label}`}
                />
                <Legend />
                <Bar 
                  dataKey="value" 
                  name="Avg. Home Price" 
                  fill="#2563eb" 
                  barSize={40}
                />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>
      
      {/* Neighborhood Insights */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Market Insights</CardTitle>
            <CardDescription>Key trends affecting property values</CardDescription>
          </CardHeader>
          <CardContent>
            <ul className="space-y-4">
              <li className="flex items-start space-x-2">
                <div className="p-1 bg-green-100 rounded-full mt-0.5">
                  <TrendingUp className="h-4 w-4 text-green-600" />
                </div>
                <div>
                  <p className="font-medium">Strong appreciation</p>
                  <p className="text-sm text-neutral-600">
                    Properties in this area have shown consistent growth at {selectedNeighborhood.annualAppreciation}% per year, outpacing the regional average.
                  </p>
                </div>
              </li>
              <li className="flex items-start space-x-2">
                <div className="p-1 bg-amber-100 rounded-full mt-0.5">
                  <Flame className="h-4 w-4 text-amber-500" />
                </div>
                <div>
                  <p className="font-medium">Competitive market</p>
                  <p className="text-sm text-neutral-600">
                    Homes in this neighborhood typically receive multiple offers and sell within 15 days of listing.
                  </p>
                </div>
              </li>
              <li className="flex items-start space-x-2">
                <div className="p-1 bg-blue-100 rounded-full mt-0.5">
                  <DollarSign className="h-4 w-4 text-primary" />
                </div>
                <div>
                  <p className="font-medium">Price stability</p>
                  <p className="text-sm text-neutral-600">
                    Property values have remained resilient even during market fluctuations, indicating strong fundamentals.
                  </p>
                </div>
              </li>
            </ul>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader>
            <CardTitle>Location Amenities</CardTitle>
            <CardDescription>What makes this neighborhood desirable</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div>
                <h4 className="font-medium">School Ratings</h4>
                <div className="flex items-center mt-1">
                  <div className="h-2 bg-primary rounded-full w-[85%]"></div>
                  <span className="text-sm ml-2">8.5/10</span>
                </div>
                <p className="text-xs text-neutral-600 mt-1">Based on public school test scores and ratings</p>
              </div>
              
              <div>
                <h4 className="font-medium">Walk Score</h4>
                <div className="flex items-center mt-1">
                  <div className="h-2 bg-teal-600 rounded-full w-[72%]"></div>
                  <span className="text-sm ml-2">72/100</span>
                </div>
                <p className="text-xs text-neutral-600 mt-1">Very walkable - most errands can be accomplished on foot</p>
              </div>
              
              <div>
                <h4 className="font-medium">Transit Score</h4>
                <div className="flex items-center mt-1">
                  <div className="h-2 bg-amber-500 rounded-full w-[65%]"></div>
                  <span className="text-sm ml-2">65/100</span>
                </div>
                <p className="text-xs text-neutral-600 mt-1">Good transit - many public transportation options</p>
              </div>
              
              <div>
                <h4 className="font-medium">Safety Score</h4>
                <div className="flex items-center mt-1">
                  <div className="h-2 bg-green-600 rounded-full w-[90%]"></div>
                  <span className="text-sm ml-2">90/100</span>
                </div>
                <p className="text-xs text-neutral-600 mt-1">Very safe - crime rates well below national average</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default NeighborhoodAnalytics;
