/**
 * Shared type definitions for the application
 */

import { Property, Neighborhood, PriceEstimate } from '@shared/schema';

/**
 * Property search filter parameters
 */
export interface PropertySearchFilters {
  minPrice?: number;
  maxPrice?: number;
  minBedrooms?: number;
  minBathrooms?: number;
  minSquareFeet?: number;
  maxSquareFeet?: number;
  propertyTypes?: string[];
  hasGarage?: boolean;
  hasPool?: boolean;
  hasFireplace?: boolean;
  hasRenovatedKitchen?: boolean;
  hasBasement?: boolean;
  hasSolarPanels?: boolean;
  city?: string;
  state?: string;
  zipCode?: string;
  searchQuery?: string;
}

/**
 * Pagination state for listings
 */
export interface PaginationState {
  currentPage: number;
  totalPages: number;
  itemsPerPage: number;
  totalItems: number;
}

/**
 * Factors used in property value estimation
 */
export interface EstimationFactors {
  address: string;
  squareFeet: number;
  bedrooms: number;
  bathrooms: number;
  yearBuilt?: number;
  propertyType: string;
  locationDemand?: 'high' | 'medium' | 'low';
  features?: {
    hasGarage?: boolean;
    hasPool?: boolean;
    hasFireplace?: boolean;
    hasRenovatedKitchen?: boolean;
    hasBasement?: boolean;
    hasSolarPanels?: boolean;
    [key: string]: boolean | undefined;
  };
}

/**
 * Property comparison selection
 */
export interface PropertyComparisonSelection {
  properties: (Property | null)[];
  searchTerms: string[];
}

/**
 * Neighborhood analytics metrics
 */
export interface NeighborhoodMetrics {
  averagePrice: number;
  pricePerSqFt: number;
  annualAppreciation: number;
  marketHeat: string;
  schoolRating?: number;
  walkScore?: number;
  transitScore?: number;
  safetyScore?: number;
}

/**
 * Price trend data point
 */
export interface PriceTrendDataPoint {
  date: Date;
  price: number;
  changePercent: number;
}

/**
 * Market activity summary
 */
export interface MarketActivity {
  totalListings: number;
  averageDaysOnMarket: number;
  percentListToSale: number;
  activeListings: number;
  soldLastMonth: number;
}

/**
 * Property sort options
 */
export type PropertySortOption = 
  | 'recommended' 
  | 'price-asc' 
  | 'price-desc' 
  | 'newest'
  | 'oldest'
  | 'bedrooms-desc'
  | 'sqft-desc';
