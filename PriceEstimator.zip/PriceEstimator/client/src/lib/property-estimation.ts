/**
 * Property Estimation Library
 * Contains functions for estimating property values
 */

import { EstimationFactors } from './types';

// Base price per square foot for different property types
const BASE_PRICE_PER_SQFT = {
  'Single Family Home': 300,
  'Condo/Townhouse': 350,
  'Multi-Family': 280,
  'Land': 100
};

// Value adjustments for bedrooms
const BEDROOM_ADJUSTMENT = 15000; // per bedroom

// Value adjustments for bathrooms
const BATHROOM_ADJUSTMENT = 10000; // per bathroom

// Adjustment for property age (per year)
const AGE_ADJUSTMENT_PER_YEAR = 500;

// Feature adjustments
const FEATURE_ADJUSTMENTS = {
  hasGarage: 20000,
  hasPool: 30000,
  hasFireplace: 5000,
  hasRenovatedKitchen: 25000,
  hasBasement: 20000,
  hasSolarPanels: 15000
};

// Location adjustment factor
const LOCATION_PREMIUM = {
  'high': 1.3, // High-demand areas
  'medium': 1.0, // Average areas
  'low': 0.8 // Low-demand areas
};

/**
 * Calculate base property value based on square footage and property type
 */
export function calculateBaseValue(squareFeet: number, propertyType: string): number {
  const pricePerSqFt = BASE_PRICE_PER_SQFT[propertyType as keyof typeof BASE_PRICE_PER_SQFT] || 
                        BASE_PRICE_PER_SQFT['Single Family Home'];
  return squareFeet * pricePerSqFt;
}

/**
 * Calculate adjustments based on property features
 */
export function calculateFeatureAdjustments(features: Record<string, boolean>): number {
  let adjustment = 0;
  
  Object.entries(features).forEach(([feature, hasFeature]) => {
    if (hasFeature && feature in FEATURE_ADJUSTMENTS) {
      adjustment += FEATURE_ADJUSTMENTS[feature as keyof typeof FEATURE_ADJUSTMENTS];
    }
  });
  
  return adjustment;
}

/**
 * Calculate property age adjustment
 */
export function calculateAgeAdjustment(yearBuilt: number): number {
  const currentYear = new Date().getFullYear();
  const age = currentYear - yearBuilt;
  
  // Newer homes get a premium, older homes get a reduction
  return Math.max(age, 0) * -AGE_ADJUSTMENT_PER_YEAR;
}

/**
 * Calculate room-based adjustments (bedrooms and bathrooms)
 */
export function calculateRoomAdjustments(bedrooms: number, bathrooms: number): number {
  return (bedrooms * BEDROOM_ADJUSTMENT) + (bathrooms * BATHROOM_ADJUSTMENT);
}

/**
 * Apply location factor to property value
 */
export function applyLocationFactor(value: number, locationDemand: 'high' | 'medium' | 'low'): number {
  return value * LOCATION_PREMIUM[locationDemand];
}

/**
 * Generate a confidence score for the estimate (0-100)
 * Higher scores indicate more reliable estimates
 */
export function calculateConfidenceScore(factors: EstimationFactors): number {
  let score = 80; // Base score
  
  // If we have comprehensive property details, increase confidence
  if (factors.squareFeet && factors.bedrooms && factors.bathrooms && factors.yearBuilt) {
    score += 10;
  }
  
  // If we know about multiple property features, increase confidence
  const featureCount = Object.values(factors.features || {}).filter(Boolean).length;
  if (featureCount >= 3) {
    score += 5;
  }
  
  // Newer properties tend to have more consistent pricing
  if (factors.yearBuilt && factors.yearBuilt > 2000) {
    score += 5;
  }
  
  // Cap at 100
  return Math.min(score, 100);
}

/**
 * Calculate estimated property value with all factors
 */
export function estimatePropertyValue(factors: EstimationFactors): {
  estimatedValue: number;
  minValue: number;
  maxValue: number;
  confidenceScore: number;
} {
  // Calculate base value from square footage and property type
  const baseValue = calculateBaseValue(
    factors.squareFeet, 
    factors.propertyType || 'Single Family Home'
  );
  
  // Calculate adjustments
  const featureAdjustments = calculateFeatureAdjustments(factors.features || {});
  const ageAdjustment = factors.yearBuilt ? calculateAgeAdjustment(factors.yearBuilt) : 0;
  const roomAdjustments = calculateRoomAdjustments(factors.bedrooms, factors.bathrooms);
  
  // Calculate total value
  let estimatedValue = baseValue + featureAdjustments + ageAdjustment + roomAdjustments;
  
  // Apply location factor if provided
  if (factors.locationDemand) {
    estimatedValue = applyLocationFactor(estimatedValue, factors.locationDemand);
  }
  
  // Calculate confidence score
  const confidenceScore = calculateConfidenceScore(factors);
  
  // Generate a value range based on confidence
  const varianceFactor = (100 - confidenceScore) / 100 * 0.15 + 0.05; // 5-20% variance based on confidence
  const minValue = Math.round(estimatedValue * (1 - varianceFactor));
  const maxValue = Math.round(estimatedValue * (1 + varianceFactor));
  
  return {
    estimatedValue: Math.round(estimatedValue),
    minValue,
    maxValue,
    confidenceScore
  };
}
